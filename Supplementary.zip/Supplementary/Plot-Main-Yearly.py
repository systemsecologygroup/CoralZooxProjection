# -*- coding: utf-8 -*-
from __future__ import division

from scipy import exp, linspace, array, zeros, e, sqrt, mean,var, ones, cumsum, random, sin, pi, load
from scipy.stats import norm
from numpy import amin, amax, meshgrid, arange, isnan, logical_not, interp, concatenate, floor
from scipy.integrate import odeint
from matplotlib import pyplot as plt
import matplotlib
from matplotlib.font_manager import FontProperties

#### Plotting data collected from ode solver #####

font = {'family' : 'normal',
        'weight' : 'bold'}
#matplotlib.rc('font',**{'family':'Times', 'sans-serif':['Times']})
#matplotlib.rc('text', usetex = True)
#matplotlib.rc('font', **font)


plt.rcParams["font.family"] = "arial"   

font0 = FontProperties()
font = font0.copy()
weight = "bold"
font.set_weight(weight)   
# Needed Parameters
Ksmax = 3e6 # healthy measure of carying capacity of symbiont per host biomass Gamma

# Temperature limited growth
T0_list = array([26.78, 28.13, 27.10]) 
skew_list = array([0.0002, 3.82, 1.06])
rho_list = array([1.0, 0.81, 0.89])

# For model with bleaching
scale = (12**2)*1e-11
rawNum_GBR = arange(0.01, 0.1, 0.00005)
rawNum_SEA = arange(0.01, 0.1, 0.00005)
rawNum_CAR = arange(0.01, 0.1, 0.00005) 

fsize = 14 #18 #22
fsize2 = 16 #18

# Open Files

Locations = ["GBR", "SEA", "CAR"]
RCP = ["RCP26", "RCP45", "RCP85"] # for filename
#RCP_title =  ["Low (RCP2.6)", "Moderate (RCP4.5)", "High (RCP8.5)"]
RCP_title =  ["RCP 2.6", "RCP 4.5", "RCP 8.5"]
Fig_lab = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l"]
#Fig_lab = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L"]

# Colorbar setting
import matplotlib.colors as mcolors
import matplotlib as mpl
 
fig =plt.figure(figsize=(14, 20))
ax = plt.subplot(1, 1, 1)

AddTime = 2000 # spine up of 2000 years

ParamsPlus= ["Gmax-Plus", "a-Plus", "b-Plus", "KC-Plus", "Ksmax-Plus", "MC-Plus", "alpha-Plus", "r-Plus", "beta-Plus", "GammaH-Plus"]
ind = 1

Color_list = [(0.306, 0.431+0.1, 0.545+0.3), (0.839+0.025, 0.60+0.05, 0.20), (0.839+0.16, 0.363, 0.35)]
Locations_title = ["Great Barrier Reef", "South East Asia", "Caribbean"]


count = 0

TempList = linspace(0, 75, 1500)
Col = [(0.827, 0.553, 0.686), (0.69, 0.345, 0.514), (0.416, 0.071, 0.239)]
# Plot effect of Forcing
Gmax = 10
  
line = []

todayTime = 2015
todayTime1 = 2010

for z in xrange(len(Locations)):
    T0 = T0_list[z]
    rho = rho_list[z]
    skew = skew_list[z]
    sub0 = plt.subplot(4, 3, count+1)
    sub0.tick_params(axis = "x", direction = "in", labelsize = 10)
    sub0.set_xticks([20, 22, 24, 26, 28, 30, 32, 34])
    sub0.set_xticklabels(["%d"%i for i in (20, 22, 24, 26, 28, 30, 32)]+[u"34\N{DEGREE SIGN}C"])
    #plt.text(34.3, -1.1, u"\N{DEGREE SIGN}C", fontsize = 10)
    part1 = sub0.twinx()
    plt.title(Locations_title[z], fontsize = fsize, fontproperties = font)
    TempCORListCenter = (TempList - T0)/rho
    NormCor = norm.pdf(TempCORListCenter)*norm.cdf(TempCORListCenter*skew)
    Dist = Gmax*norm.pdf(TempCORListCenter)*norm.cdf(TempCORListCenter*skew)/max(NormCor)
    plt.plot(TempList, Dist, color=Col[z], linewidth = 4)
    for v in xrange(len(RCP)):
        rcp = RCP[v]
        file0 = open("Years-"+Locations[z]+"-"+rcp+"-MPI"+".dat", "r")
        #file0 = open("Months-"+Locations[z]+"-"+rcp+"-MPI"+".dat", "r")

        time0 = load(file0, allow_pickle = True)
        file0.close()
        file1 = open("SST-"+Locations[z]+"-"+rcp+"-MPI"+".dat", "r")
        #file1 = open("SST-"+Locations[z]+"-"+rcp+"-MPI"+".dat", "r")

        SST = load(file1, allow_pickle = True)
        file1.close()
        today = list(time0).index(todayTime) # 2015
        today1 = list(time0).index(todayTime1)
        century = list(time0).index(2100)
        #for i in xrange(len(SST[today:today1+1])):
            #print Locations[z], rcp, len(SST), i
            #TempCORListCenter_i = (SST[i] - T0)/rho
            #Disti = Gmax*norm.pdf(TempCORListCenter_i)*norm.cdf(TempCORListCenter_i*skew)/max(NormCor)
            #sub0.plot(SST[i]*ones(5), linspace(0, 10.2, 5), "-", linewidth = 0.5, alpha = 0.2)     
        if v == 0 and z == 1:
            #sub0.plot(mean(SST[today:today1+1])*ones(5), linspace(0, 10.2, 5), "-", linewidth = 4, color = "black", alpha = 0.65, label = "SST %d--%d"%(todayTime, todayTime1))
            sub0.plot(SST[today]*ones(5), linspace(0, 10.2, 5), "-", linewidth = 4, color = "black", alpha = 0.65, label = "SST %d"%todayTime)
        elif v == 0 and z in (0, 2):
            #sub0.plot(mean(SST[today:today1+1])*ones(5), linspace(0, 10.2, 5), "-", linewidth = 4, color = "black", alpha = 0.65)
            sub0.plot(SST[today]*ones(5), linspace(0, 10.2, 5), "-", linewidth = 4, color = "black", alpha = 0.65)

        sub0.plot(SST[century]*ones(2), linspace(0, 10.2, 2), "-", linewidth = 3, color = Color_list[v], label = RCP_title[v]+" (2100)")        
        if count == 0:
            sub0.set_ylabel("Temperature-limited \n coral growth rate \n (year$^{-1}$)", labelpad = 2, fontsize = fsize2)
            plt.text(17.8, 10., Fig_lab[count],fontproperties=font, fontsize = fsize)
        else:
            plt.text(19.15, 10., Fig_lab[count],fontproperties=font, fontsize = fsize)
        plt.xlabel(u"Temperature (\N{DEGREE SIGN}C)", fontsize = 15)
    if z==1:
        sub0.legend(loc = "upper left", fontsize = 9, frameon = True)
    
    if count in (0, ):
        sub0.tick_params(axis = "y", direction = "in", labelsize = fsize2)
        sub0.set_yticks((0, 2, 4, 6, 8, 10))
        part1.tick_params(axis = "y", direction = "in") 
        part1.set_yticks((0, 2, 4, 6, 8, 10))
        part1.set_yticklabels(("", "", "", "", "", ""))
        part1.set_ylim((0, 10.))
    elif count in (1, 2):
        sub0.tick_params(axis = "y", direction = "in", labelsize = fsize2)
        sub0.set_yticks((0, 2, 4, 6, 8, 10))
        sub0.set_yticklabels(("", "", "", "", "", ""))
        part1.tick_params(axis = "y", direction = "in")
        part1.set_yticks((0, 2, 4, 6, 8, 10))
        part1.set_yticklabels(("", "", "", "", "", ""))
        part1.set_ylim((0, 10.))
    sub0.set_xlim((20, 34))
    sub0.set_ylim((0, 10.))
    count += 1

count = 3

# Regional coral carrying capacity
K_C_GBR = 438718.902336e10 # in cm^2
K_C_SEA = 1191704.68901e10 # in cm^2
K_C_CAR = 190374.697987e10  # in cm^2

Ksmax = 3e6 # healthy measure of carying capacity of symbiont per host biomass Gamma

file_list = ["Results-yearly/"]

#  Speed of adapations specific for each region # index in N_list
GBR_N_index = 908 # index in rawNum_GBR  0.0554
SEA_N_index = 330 #340 # index in rawNum_SEA
CAR_N_index = 275 # index in rawNum_CAR  0.02375

GBR_N_index = 0 # index in rawNum_GBR  0.0554
SEA_N_index = 0 #340 # index in rawNum_SEA
CAR_N_index = 0 # index in rawNum_CAR  0.02375

reg_N_index = [GBR_N_index, SEA_N_index, CAR_N_index]

startTime = 2010
for z in xrange(len(Locations)):
    for v in xrange(len(RCP)):
        rcp = RCP[v]
    
        file0 = open("Years-"+Locations[z]+"-"+rcp+"-MPI"+".dat", "r")
        time0 = load(file0, allow_pickle = True)
        file0.close()
        time = concatenate((arange(min(time0)-(AddTime+1), min(time0), 1), time0))   # time are already given in year
        file1 = open("SST-"+Locations[z]+"-"+rcp+"-MPI"+".dat", "r")
        TempNS = load(file1, allow_pickle = True)
        file1.close()
            
        sub1 = plt.subplot(4, 3, 1+count)
        TraitTicks = array([100, 101, 102, 103])
        plt.xticks([2010, 2020, 2030, 2040, 2050, 2060, 2070, 2080, 2090, 2100], ["", "", "", "", "", "", "", "", "", ""], fontsize = 10)
        part1 = sub1.twinx() 
        if count == 3: 
            sub1.set_ylabel("Coral trait \n (% change)", fontsize = fsize + 2)
            sub1.text(2010 - 17, 102.8, Fig_lab[count], fontproperties=font,  fontsize = fsize)
        else:
            sub1.text(2010 - 5, 102.8, Fig_lab[count], fontproperties=font, fontsize = fsize) # forcing
            if 1+count == 2:
                plt.title(Locations[z], fontsize = fsize)
            elif 1+count == 3:
                plt.title(Locations[z], fontsize = fsize)
            
        sub4 = plt.subplot(4, 3, 4+count)
        plt.xticks([2010, 2020, 2030, 2040, 2050, 2060, 2070, 2080, 2090, 2100], ["", "", "", "", "", "", "", "", "", ""], fontsize = fsize2)
        part4 = sub4.twinx()
        hostTicks = array([40, 60, 80, 100, 120, 140])     
        if count == 3:
            sub4.set_ylabel("Coral abundance \n (% change)", fontsize = fsize + 2)
            sub4.text(2010 - 17, 140, Fig_lab[3+count],fontproperties=font, fontsize = fsize) # forcing
        else: 
            sub4.text(2010 - 5, 140, Fig_lab[3+count],fontproperties=font, fontsize = fsize) # forcing
        sub4.set_ylim((40, 140))
        
        sub7 = plt.subplot(4, 3, 7+count)
        plt.xticks([2010, 2020, 2030, 2040, 2050, 2060, 2070, 2080, 2090, 2100], rotation = 45, fontsize = fsize2)
        plt.xlim((2010, max(time0))) 
        
        Symbticks = array([40, 60, 80, 100, 120, 140])       
        part7 = sub7.twinx()
        if count==3:
            sub7.set_ylabel("Symbiont abundance \n (% change)\n", fontsize = fsize + 2)
            sub7.text(2010 - 16, 140, Fig_lab[6+count], fontproperties=font, fontsize = fsize) # forcing
        else:
            sub7.text(2010 - 5, 140, Fig_lab[6+count], fontproperties=font, fontsize = fsize) # forcing
        
        for file_index in xrange(len(file_list)):
            filename = file_list[file_index]
            file2 = open(filename+rcp+"/CORAL-"+rcp+"-"+Locations[z]+".dat", "r")
            HOSTSet1 = load(file2, allow_pickle = True)
            file2.close()
            
            file3 = open(filename+rcp+"/TRAIT-"+rcp+"-"+Locations[z]+".dat", "r")
            TRAITSet1 = load(file3, allow_pickle = True)
            file3.close()
            
            file4 =  open(filename+rcp+"/SYMB-"+rcp+"-"+Locations[z]+".dat", "r")
            SYMBSet1 = load(file4, allow_pickle = True)
            file4.close()
            
            HOST = HOSTSet1
            SYMB = SYMBSet1
            TRAIT = TRAITSet1
        
            MeanlossCoralBiomass = []
            if file_index == 0 and z == 0:
                N_index = reg_N_index[z]
                Host = HOST[N_index]
                Trait = TRAIT[N_index]
                Symb = SYMB[N_index]  
                compare0 = (time<=2005)*(time>=1986)
                
                PastHost = sum(Host[compare0])/sum(compare0)
                PastTrait = sum(Trait[compare0])/sum(compare0)
                PastSymb = sum(Symb[compare0])/sum(compare0)
                
                sub1.plot(time, 100*Trait/PastTrait, linewidth = 3, color = Color_list[v])                 
                sub4.plot(time, 100*Host/PastHost, linewidth = 3, color = Color_list[v])                
                sub7.plot(time, 100*Symb/PastSymb, linewidth = 3, color = Color_list[v], label = RCP_title[v])
                
                compare1 = (time<=2100)*(time>=2081)     
                FutureHost = sum(Host[compare1])/sum(compare1)
                MeanlossCoralBiomass.append((FutureHost-PastHost)/PastHost)
                PerChange = mean(array(MeanlossCoralBiomass))*100
                print rcp, Locations[z], PerChange, "N = ", rawNum_GBR[N_index]*scale          
            elif file_index == 0 and z == 1:
                N_index = reg_N_index[z]
                Host = HOST[N_index]
                Trait = TRAIT[N_index]
                Symb = SYMB[N_index]
                compare0 = (time<=2005)*(time>=1986)
                
                PastHost = sum(Host[compare0])/sum(compare0)
                PastTrait = sum(Trait[compare0])/sum(compare0)
                PastSymb = sum(Symb[compare0])/sum(compare0)
                
                sub1.plot(time, 100*Trait/PastTrait, linewidth = 3, color = Color_list[v]) 
                
                sub4.plot(time, 100*Host/PastHost, linewidth = 3, color = Color_list[v])
                
                sub7.plot(time, 100*Symb/PastSymb, linewidth = 3, color = Color_list[v], label = RCP_title[v])
                
                compare1 = (time<=2100)*(time>=2081)     
                FutureHost = sum(Host[compare1])/sum(compare1)
                MeanlossCoralBiomass.append((FutureHost-PastHost)/PastHost)
                PerChange = mean(array(MeanlossCoralBiomass))*100
                print rcp, Locations[z], PerChange, "N = ", rawNum_SEA[N_index]*scale       
            elif file_index == 0 and z == 2:
                N_index = reg_N_index[z]
                Host = HOST[N_index]
                Trait = TRAIT[N_index]
                Symb = SYMB[N_index] 
                compare0 = (time<=2005)*(time>=1986)
                
                PastHost = sum(Host[compare0])/sum(compare0)
                PastTrait = sum(Trait[compare0])/sum(compare0)
                PastSymb = sum(Symb[compare0])/sum(compare0)
                
                sub1.plot(time, 100*Trait/PastTrait, linewidth = 3, color = Color_list[v]) 
                
                sub4.plot(time, 100*Host/PastHost, linewidth = 3, color = Color_list[v])
                
                sub7.plot(time, 100*Symb/PastSymb, linewidth = 3, color = Color_list[v], label = RCP_title[v])
                
                compare1 = (time<=2100)*(time>=2081)     
                FutureHost = sum(Host[compare1])/sum(compare1)
                MeanlossCoralBiomass.append((FutureHost-PastHost)/PastHost)
                PerChange = mean(array(MeanlossCoralBiomass))*100
                print rcp, Locations[z], PerChange, "N = ", rawNum_CAR[N_index]*scale          
                print rcp, Locations[z], PerChange, "N = ", rawNum_CAR[N_index]*scale             
        if count in (3, ):
            sub1.tick_params(axis = "y", direction = "in", labelsize = fsize2)
            sub1.set_yticks(list(TraitTicks)) # GBR and SEA
            sub1.set_yticklabels(list(["%d"%(TraitTicks[s]-100) for s in xrange(len(TraitTicks))]))
            part1.tick_params(axis = "y", direction = "in", labelsize = fsize2) 
            part1.set_yticks(TraitTicks)
            part1.set_yticklabels([" "%d for d in TraitTicks])
            
            sub4.tick_params(axis = "y", direction = "in", labelsize = fsize2)
            sub4.set_yticks(list(hostTicks))
            sub4.set_yticklabels(list(["%d"%(hostTicks[k]-100) for k in xrange(len(hostTicks))]))
            part4.tick_params(axis = "y", direction = "in", labelsize = fsize2) 
            part4.set_yticks(hostTicks)
            part4.set_yticklabels([" "%d for d in hostTicks])
            
            sub7.tick_params(axis = "y", direction = "in", labelsize = fsize2)
            sub7.set_yticks(list(Symbticks))
            sub7.set_yticklabels(list(["%d"%(Symbticks[s]-100) for s in xrange(len(Symbticks))]))
            part7.tick_params(axis = "y", direction = "in", labelsize = fsize2) 
            part7.set_yticks(Symbticks)
            part7.set_yticklabels([" "%d for d in Symbticks])
        else:
            sub1.tick_params(axis = "y", direction = "in", labelsize = fsize2)
            sub1.set_yticks(list(TraitTicks))
            sub1.set_yticklabels([" "]+list([" " for s in xrange(1, len(TraitTicks))]))
            part1.tick_params(axis = "y", direction = "in", labelsize = fsize2) 
            part1.set_yticks(TraitTicks)
            part1.set_yticklabels([" "%d for d in TraitTicks])
            
            sub4.tick_params(axis = "y", direction = "in", labelsize = fsize2)
            sub4.set_yticks(list(hostTicks))
            sub4.set_yticklabels([" "]+list([" " for k in xrange(1, len(hostTicks))]))
            part4.tick_params(axis = "y", direction = "in", labelsize = fsize2) 
            part4.set_yticks(hostTicks)
            part4.set_yticklabels([" "%d for d in hostTicks])
            
            sub7.tick_params(axis = "y", direction = "in", labelsize = fsize2)
            sub7.set_yticks(list(Symbticks))
            sub7.set_yticklabels([" "]+list([" " for s in xrange(1, len(Symbticks))]))
            part7.tick_params(axis = "y", direction = "in", labelsize = fsize2) 
            part7.set_yticks(Symbticks)
            part7.set_yticklabels([" "%d for d in Symbticks])           
        sub1.set_ylim((100, 103))
        sub1.set_xlim((startTime, max(time0))) 
        part1.set_ylim((100, 103))
        part1.set_xlim((startTime, max(time0))) 
        
        sub4.set_xlim((startTime, max(time0))) 
        sub4.set_ylim((40, 140))
        part4.set_ylim((40, 140))
        sub4.set_xlim((startTime, max(time0))) 
        
        sub7.set_ylim((40, 140))
        part7.set_ylim((40, 140)) 
        sub7.set_xlim((startTime, max(time0))) 
        sub7.set_xlabel("Years", fontsize=fsize2)            
    count +=1
# Plot with maximal window
figManager = plt.get_current_fig_manager()
figManager.window.showMaximized()

# Adjust margins
plt.subplots_adjust(bottom = 0.10, right = 0.81, left = 0.20, top = 0.96, wspace = 0.11, hspace = 0.19)

plt.savefig("Figure5.pdf", bbox_inches = 'tight') 



# Plotting Spine up, although, in the end I did not need this for the manuscript so it might give some error because I did not update it 
Color_list = [(0.651, 0.325, 0.529), (0.839+0.025, 0.60+0.05, 0.20), (0.839+0.16, 0.363, 0.35)]
"""
for z in xrange(len(Locations)):
    for v in xrange(1):#len(RCP)):
        rcp = RCP[v]
        file0 = open("Years-"+Locations[z]+"-"+rcp+"-MPI"+".dat", "r")
        time0 = load(file0)
        file0.close()
        time = concatenate((arange(min(time0)-AddTime, min(time0), 1), time0))   # time are already given in year
        file1 = open("SST-"+Locations[z]+"-"+rcp+"-MPI"+".dat", "r")
        TempNS = load(file1)
        file1.close()
            
        sub1 = plt.subplot(4, 3, 1+count)
        plt.title(Locations_title[z], fontsize = fsize, fontproperties = font)
        TraitTicks = array([0, 20, 40, 60, 80, 100])/100
        plt.xticks([0, 955, 2016], ["", "", ""], fontsize = 10)
        #plt.xticks([2016, 2100], ["", "", ""], fontsize = 10)

        plt.xlim((min(time), 2016))# min(time0))) 
        #plt.xlim((2016, max(time)))       
            
        if count == 3:
            plt.yticks(list(TraitTicks), ["$0$"]+list(["%.1f"%TraitTicks[s] for s in xrange(1, len(TraitTicks))])) # GBR and SEA
            plt.ylabel("Normalized \n Trait $U$", fontsize = fsize)
            plt.text(min(time) - 200, 1.00, Fig_lab[count], fontproperties=font,  fontsize = fsize)
        else:
            plt.yticks(list(TraitTicks), [" "]+list([" " for s in xrange(1, len(TraitTicks))]))
            plt.text(min(time) - 50, 1.00, Fig_lab[count], fontproperties=font,  fontsize = fsize)

        plt.ylim((0, 1.00))
            
        plt.tick_params(labelsize=fsize2)
        sub4 = plt.subplot(4, 3, 4+count)
        plt.xticks([0, 955 , 2016], ["", "", ""], fontsize = 10)
        #plt.xticks([2016, 2100], ["", "", ""], fontsize = 10)

        plt.xlim((min(time), 2016))# min(time0))) 
        #plt.xlim((2016, max(time)))       
                  
        hostTicks = array([0, 20, 40, 60, 80, 100])/100 
        plt.tick_params(labelsize=fsize2)
        if count == 3:
            plt.yticks(list(hostTicks), ["$0$"]+list(["%.1f"%hostTicks[k] for k in xrange(1, len(hostTicks))]), fontsize = fsize2)
            #plt.ylabel("Coral $C$ \n ($\%$ to carrying capacity)", fontsize = fsize)
            #plt.ylabel("Coral $C$ \n ($\%$ of $K_C$)", fontsize = fsize)
            plt.ylabel("Normalized \n Coral Biomass $C$", fontsize = fsize)
            plt.text(min(time) - 200, 1.00, Fig_lab[3+count],fontproperties=font, fontsize = fsize) # forcing
        else: 
            plt.yticks(list(hostTicks), [" "]+list([" " for k in xrange(1, len(hostTicks))]))
            plt.text(min(time) - 50, 1.00, Fig_lab[3+count],fontproperties=font, fontsize = fsize) # forcing
        
        plt.ylim((0,1.00))
        
        sub7 = plt.subplot(4, 3, 7+count)
        #plt.xticks([0, 955 , 2016], fontsize = fsize2)
        #plt.xticks([2016, 2100], fontsize = 10)

        plt.xlim((min(time), 2016))# min(time0))) 
        #plt.xlim((2016, max(time)))       

        plt.xlabel("Years", fontsize=fsize)
        Symbticks = array([0, 20, 40, 60, 80, 100])/100
        
        if count==3:
            plt.yticks(list(Symbticks), ["$0$"]+list(["%.1f"%Symbticks[s] for s in xrange(1, len(Symbticks))]))
            plt.ylabel("Normalized \n Symbiont Biomass $S$", fontsize = fsize)
            plt.text(min(time) - 200, 1.00, Fig_lab[6+count], fontproperties=font, fontsize = fsize) # forcing
        else:
            plt.yticks(list(Symbticks*1e14), [" "]+list([" " for s in xrange(1, len(Symbticks))]))
            plt.text(min(time) - 50, 1.00, Fig_lab[6+count], fontproperties=font, fontsize = fsize) # forcing
        
        plt.ylim((0, 1.00))
                
        plt.tick_params(labelsize=fsize2)
            
        for file_index in xrange(len(file_list)):
            filename = file_list[file_index]
            file2 = open(filename+rcp+"/CORAL-"+rcp+"-"+Locations[z]+".dat", "r")
            HOSTSet1 = load(file2)
            file2.close()
            
            file3 = open(filename+rcp+"/TRAIT-"+rcp+"-"+Locations[z]+".dat", "r")
            TRAITSet1 = load(file3)
            file3.close()
            
            file4 =  open(filename+rcp+"/SYMB-"+rcp+"-"+Locations[z]+".dat", "r")
            SYMBSet1 = load(file4)
            file4.close()
            
            HOST = HOSTSet1
            SYMB = SYMBSet1
            TRAIT = TRAITSet1
            
            MeanlossCoralBiomass = []
                        
            N_List = (scale)*rawNum_list[file_index]
            
            if z == 0:
                display = len(N_List) - 8
            else:
                display = len(N_List) - 9
            for i in xrange(display):
                Host = HOST[i]
                Trait = TRAIT[i]
                Symb = SYMB[i]     
                compare0 = (time<=2005)*(time>=1986)
                PastHost = sum(Host[compare0])/sum(compare0)
                PastTrait = sum(Trait[compare0])/sum(compare0)
                PastSymb = sum(Symb[compare0])/sum(compare0)
                #sub1.plot(time, 100*Trait/PastTrait, linewidth = 0.75, color = Color_list[v], alpha = 0.35) 
                sub1.plot(time, Trait/8e-5, linewidth = 0.75, color = Color_list[v], alpha = 0.25)
                #sub4.plot(time, 100*Host/PastHost, linewidth = 0.75, color = Color_list[v], alpha = 0.35)
                sub4.plot(time, Host/K_C, linewidth = 0.75, color = Color_list[v], alpha = 0.25)                
                #sub7.plot(time, 100*Symb/PastSymb, linewidth = 0.75, color = Color_list[v], alpha = 0.35)
                sub7.plot(time, Symb/(Ksmax*K_C), linewidth = 0.75, color = Color_list[v], alpha = 0.25)
            
            if file_index == 0 and z == 0:
                N_index = reg_N_index[z]
                print Locations[z], filename
                Host = HOST[N_index]
                Trait = TRAIT[N_index]
                Symb = SYMB[N_index]  
                compare0 = (time<=2005)*(time>=1986)
                
                PastHost = sum(Host[compare0])/sum(compare0)
                PastTrait = sum(Trait[compare0])/sum(compare0)
                PastSymb = sum(Symb[compare0])/sum(compare0)
                
                #sub1.plot(time, 100*Trait/PastTrait, linewidth = 3, color = Color_list[v]) 
                sub1.plot(time, Trait/8e-5, linewidth = 3, color = Color_list[v])
                #sub1.fill_between(time, 100*lower_bound_Trait/PastTrait, 100*upper_bound_Trait/PastTrait, facecolor= Color_list[v], alpha=0.25)
                
                #sub4.plot(time, 100*Host/PastHost, linewidth = 3, color = Color_list[v])
                sub4.plot(time, Host/K_C, linewidth = 3, color = Color_list[v])
                #sub4.fill_between(time, 100*lower_bound_Host/PastHost, 100*upper_bound_Host/PastHost, facecolor= Color_list[v], alpha=0.25)
                
                #sub7.plot(time, 100*Symb/PastSymb, linewidth = 3, color = Color_list[v], label = RCP_title[v])
                sub7.plot(time, Symb/(Ksmax*K_C), linewidth = 3, color = Color_list[v], label = RCP_title[v])
                #sub7.fill_between(time, 100*lower_bound_Symb/PastSymb, 100*upper_bound_Symb/PastSymb, facecolor= Color_list[v], alpha=0.25)
                
                compare1 = (time<=2100)*(time>=2081)     
                FutureHost = sum(Host[compare1])/sum(compare1)
                MeanlossCoralBiomass.append((FutureHost-PastHost)/PastHost)
                PerChange = mean(array(MeanlossCoralBiomass))*100
                print rcp, Locations[z], PerChange         
            elif file_index == 0 and z == 1:
                N_index = reg_N_index[z]
                print Locations[z], filename
                Host = HOST[N_index]
                Trait = TRAIT[N_index]
                Symb = SYMB[N_index]
                compare0 = (time<=2005)*(time>=1986)
                
                PastHost = sum(Host[compare0])/sum(compare0)
                PastTrait = sum(Trait[compare0])/sum(compare0)
                PastSymb = sum(Symb[compare0])/sum(compare0)
                
                #sub1.plot(time, 100*Trait/PastTrait, linewidth = 3, color = Color_list[v]) 
                sub1.plot(time, Trait/8e-5, linewidth = 3, color = Color_list[v]) 

                #sub4.plot(time, 100*Host/PastHost, linewidth = 3, color = Color_list[v])
                sub4.plot(time, Host/K_C, linewidth = 3, color = Color_list[v])

                #sub7.plot(time, 100*Symb/PastSymb, linewidth = 3, color = Color_list[v], label = RCP_title[v])
                sub7.plot(time, Symb/(Ksmax * K_C), linewidth = 3, color = Color_list[v], label = RCP_title[v])

                compare1 = (time<=2100)*(time>=2081)     
                FutureHost = sum(Host[compare1])/sum(compare1)
                MeanlossCoralBiomass.append((FutureHost-PastHost)/PastHost)
                PerChange = mean(array(MeanlossCoralBiomass))*100
                print rcp, Locations[z], PerChange         
            elif file_index == 0 and z == 2:
                N_index = reg_N_index[z]
                print Locations[z], filename
                Host = HOST[N_index]
                Trait = TRAIT[N_index]
                Symb = SYMB[N_index] 
                compare0 = (time<=2005)*(time>=1986)
                
                PastHost = sum(Host[compare0])/sum(compare0)
                PastTrait = sum(Trait[compare0])/sum(compare0)
                PastSymb = sum(Symb[compare0])/sum(compare0)
                
                #sub1.plot(time, 100*Trait/PastTrait, linewidth = 3, color = Color_list[v]) 
                sub1.plot(time, Trait/8e-5, linewidth = 3, color = Color_list[v]) 

                #sub4.plot(time, 100*Host/PastHost, linewidth = 3, color = Color_list[v])
                sub4.plot(time, Host/K_C, linewidth = 3, color = Color_list[v])

                #sub7.plot(time, 100*Symb/PastSymb, linewidth = 3, color = Color_list[v], label = RCP_title[v])
                sub7.plot(time, Symb/(Ksmax * K_C), linewidth = 3, color = Color_list[v], label = RCP_title[v])
                
                compare1 = (time<=2100)*(time>=2081)     
                FutureHost = sum(Host[compare1])/sum(compare1)
                MeanlossCoralBiomass.append((FutureHost-PastHost)/PastHost)
                PerChange = mean(array(MeanlossCoralBiomass))*100
                print rcp, Locations[z], PerChange  
    
    count +=1
"""   

