# -*- coding: utf-8 -*-
from __future__ import division

from scipy import exp, linspace, array, zeros, e, sqrt, mean,var, ones, cumsum, random, sin, pi, load
from scipy.stats import norm
from numpy import amin, amax, meshgrid, arange, isnan, logical_not, interp, concatenate, floor
from scipy.integrate import odeint
from matplotlib import pyplot as plt
import matplotlib
from matplotlib.font_manager import FontProperties

#### Plotting data collected from ode solver #####

font = {'family' : 'normal',
        'weight' : 'bold'}
#matplotlib.rc('font',**{'family':'Times', 'sans-serif':['Times']})
#matplotlib.rc('text', usetex = True)
#matplotlib.rc('font', **font)


plt.rcParams["font.family"] = "arial"   

font0 = FontProperties()
font = font0.copy()
weight = "bold"
font.set_weight(weight)   
# Needed Parameters
Ksmax = 3e6 # healthy measure of carying capacity of symbiont per host biomass Gamma

# Temperature limited growth
T0_list = array([26.78, 28.13, 27.10]) 
skew_list = array([0.0002, 3.82, 1.06])
rho_list = array([1.0, 0.81, 0.89])

# For model with bleaching
scale = (12**2)*1e-11
rawNum_GBR = arange(0.01, 0.1, 0.00005)
rawNum_SEA = arange(0.01, 0.1, 0.00005)
rawNum_CAR = arange(0.01, 0.1, 0.00005) 

fsize = 12 #18 #22
fsize2 = 11 #18

# Open Files

Locations = ["GBR", "SEA", "CAR"]
RCP = ["RCP26", "RCP45", "RCP85"] # for filename
#RCP_title =  ["Low (RCP2.6)", "Moderate (RCP4.5)", "High (RCP8.5)"]
RCP_title =  ["RCP 2.6", "RCP 4.5", "RCP 8.5"]
#Fig_lab = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l"]
Fig_lab = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L"]

# Colorbar setting
import matplotlib.colors as mcolors
import matplotlib as mpl
 
fig =plt.figure(figsize=(14, 20))
ax = plt.subplot(1, 1, 1)

AddTime = 2000 # spine up of 2000 years

ParamsPlus= ["Gmax-Plus", "a-Plus", "b-Plus", "KC-Plus", "Ksmax-Plus", "MC-Plus", "alpha-Plus", "r-Plus", "beta-Plus", "GammaH-Plus"]
ind = 1

Color_list = [(0.306, 0.431+0.1, 0.545+0.3), (0.839+0.025, 0.60+0.05, 0.20), (0.839+0.16, 0.363, 0.35)]
Locations_title = ["Great Barrier Reef", "South East Asia", "Caribbean"]



"""
count = 0

TempList = linspace(0, 75, 1500)
Col = [(0.827, 0.553, 0.686), (0.69, 0.345, 0.514), (0.416, 0.071, 0.239)]
# Plot effect of Forcing
Gmax = 10
  
line = []

todayTime = 2015
todayTime1 = 2010

for z in xrange(len(Locations)):
    T0 = T0_list[z]
    rho = rho_list[z]
    skew = skew_list[z]
    sub0 = plt.subplot(4, 3, count+1)
    sub0.tick_params(axis = "x", direction = "in", labelsize = 10)
    sub0.set_xticks([20, 22, 24, 26, 28, 30, 32, 34])
    sub0.set_xticklabels(["%d"%i for i in (20, 22, 24, 26, 28, 30, 32, 34)])
    plt.text(34.1, -1.41, "$^\circ$C", fontsize = 10)
    part1 = sub0.twinx()
    plt.title(Locations_title[z], fontsize = fsize, fontproperties = font)
    TempCORListCenter = (TempList - T0)/rho
    NormCor = norm.pdf(TempCORListCenter)*norm.cdf(TempCORListCenter*skew)
    Dist = Gmax*norm.pdf(TempCORListCenter)*norm.cdf(TempCORListCenter*skew)/max(NormCor)
    plt.plot(TempList, Dist, color=Col[z], linewidth = 4)
    for v in xrange(len(RCP)):
        rcp = RCP[v]
        file0 = open("Years-"+Locations[z]+"-"+rcp+"-MPI"+".dat", "r")
        #file0 = open("Months-"+Locations[z]+"-"+rcp+"-MPI"+".dat", "r")

        time0 = load(file0)
        file0.close()
        file1 = open("SST-"+Locations[z]+"-"+rcp+"-MPI"+".dat", "r")
        #file1 = open("SST-"+Locations[z]+"-"+rcp+"-MPI"+".dat", "r")

        SST = load(file1)
        file1.close()
        today = list(time0).index(todayTime) # 2015
        today1 = list(time0).index(todayTime1)
        century = list(time0).index(2100)
        #for i in xrange(len(SST[today:today1+1])):
            #print Locations[z], rcp, len(SST), i
            #TempCORListCenter_i = (SST[i] - T0)/rho
            #Disti = Gmax*norm.pdf(TempCORListCenter_i)*norm.cdf(TempCORListCenter_i*skew)/max(NormCor)
            #sub0.plot(SST[i]*ones(5), linspace(0, 10.2, 5), "-", linewidth = 0.5, alpha = 0.2)     
        if v == 0 and z == 1:
            #sub0.plot(mean(SST[today:today1+1])*ones(5), linspace(0, 10.2, 5), "-", linewidth = 4, color = "black", alpha = 0.65, label = "SST %d--%d"%(todayTime, todayTime1))
            sub0.plot(SST[today]*ones(5), linspace(0, 10.2, 5), "-", linewidth = 4, color = "black", alpha = 0.65, label = "SST %d"%todayTime)
        elif v == 0 and z in (0, 2):
            #sub0.plot(mean(SST[today:today1+1])*ones(5), linspace(0, 10.2, 5), "-", linewidth = 4, color = "black", alpha = 0.65)
            sub0.plot(SST[today]*ones(5), linspace(0, 10.2, 5), "-", linewidth = 4, color = "black", alpha = 0.65)

        sub0.plot(SST[century]*ones(2), linspace(0, 10.2, 2), "-", linewidth = 3, color = Color_list[v], label = RCP_title[v]+" (2100)")        
        if count == 0:
            sub0.set_ylabel("Temperature-limited \n coral growth rate \n (year$^{-1}$)", labelpad = 2, fontsize = fsize2)
            plt.text(17.8, 10., Fig_lab[count],fontproperties=font, fontsize = fsize)
        else:
            plt.text(19.15, 10., Fig_lab[count],fontproperties=font, fontsize = fsize)
        plt.xlabel("Temperature ($^\circ$C)", fontsize = 15)
    if z==1:
        sub0.legend(loc = "upper left", fontsize = 9, frameon = True)
    
    if count in (0, ):
        sub0.tick_params(axis = "y", direction = "in", labelsize = fsize2)
        sub0.set_yticks((0, 2, 4, 6, 8, 10))
        part1.tick_params(axis = "y", direction = "in") 
        part1.set_yticks((0, 2, 4, 6, 8, 10))
        part1.set_yticklabels(("", "", "", "", "", ""))
        part1.set_ylim((0, 10.))
    elif count in (1, 2):
        sub0.tick_params(axis = "y", direction = "in", labelsize = fsize2)
        sub0.set_yticks((0, 2, 4, 6, 8, 10))
        sub0.set_yticklabels(("", "", "", "", "", ""))
        part1.tick_params(axis = "y", direction = "in")
        part1.set_yticks((0, 2, 4, 6, 8, 10))
        part1.set_yticklabels(("", "", "", "", "", ""))
        part1.set_ylim((0, 10.))
    sub0.set_xlim((20, 34))
    sub0.set_ylim((0, 10.))
    count += 1

count = 3

# Regional coral carrying capacity
K_C_GBR = 438718.902336e10 # in cm^2
K_C_SEA = 1191704.68901e10 # in cm^2
K_C_CAR = 190374.697987e10  # in cm^2

Ksmax = 3e6 # healthy measure of carying capacity of symbiont per host biomass Gamma

file_list = ["Results-final/"]

#  Speed of adapations specific for each region # index in N_list
GBR_N_index = 920 # index in rawNum_GBR  0.056
SEA_N_index = 330 #340 # index in rawNum_SEA
CAR_N_index = 275 # index in rawNum_CAR  0.02375
reg_N_index = [GBR_N_index, SEA_N_index, CAR_N_index]

startTime = 2010
for z in xrange(len(Locations)):
    for v in xrange(len(RCP)):
        rcp = RCP[v]
    
        file0 = open("Years-"+Locations[z]+"-"+rcp+"-MPI"+".dat", "r")
        time0 = load(file0)
        file0.close()
        time = concatenate((arange(min(time0)-(AddTime+1), min(time0), 1), time0))   # time are already given in year
        file1 = open("SST-"+Locations[z]+"-"+rcp+"-MPI"+".dat", "r")
        TempNS = load(file1)
        file1.close()
            
        sub1 = plt.subplot(4, 3, 1+count)
        TraitTicks = array([100, 101, 102, 103])
        plt.xticks([2010, 2020, 2030, 2040, 2050, 2060, 2070, 2080, 2090, 2100], ["", "", "", "", "", "", "", "", "", ""], fontsize = 10)
        part1 = sub1.twinx() 
        if count == 3: 
            sub1.set_ylabel("Coral trait \n (%)", labelpad = 2, fontsize = fsize)
            sub1.text(2010 - 15, 102.8, Fig_lab[count], fontproperties=font,  fontsize = fsize)
        else:
            sub1.text(2010 - 5, 102.8, Fig_lab[count], fontproperties=font, fontsize = fsize) # forcing
            if 1+count == 2:
                plt.title(Locations[z], fontsize = fsize)
            elif 1+count == 3:
                plt.title(Locations[z], fontsize = fsize)
            
        sub4 = plt.subplot(4, 3, 4+count)
        plt.xticks([2010, 2020, 2030, 2040, 2050, 2060, 2070, 2080, 2090, 2100], ["", "", "", "", "", "", "", "", "", ""], fontsize = fsize2)
        part4 = sub4.twinx()
        hostTicks = array([40, 60, 80, 100, 120, 140])     
        if count == 3:
            sub4.set_ylabel("Coral biomass \n (%)", labelpad = 2, fontsize = fsize)
            sub4.text(2010 - 15, 140, Fig_lab[3+count],fontproperties=font, fontsize = fsize) # forcing
        else: 
            sub4.text(2010 - 5, 140, Fig_lab[3+count],fontproperties=font, fontsize = fsize) # forcing
        sub4.set_ylim((40, 140))
        
        sub7 = plt.subplot(4, 3, 7+count)
        plt.xticks([2010, 2020, 2030, 2040, 2050, 2060, 2070, 2080, 2090, 2100], rotation = 45, fontsize = fsize2)
        plt.xlim((2010, max(time0))) 
        
        Symbticks = array([40, 60, 80, 100, 120, 140])       
        part7 = sub7.twinx()
        if count==3:
            sub7.set_ylabel("Symbiont biomass \n (%)", labelpad = 2, fontsize = fsize)
            sub7.text(2010 - 14, 140, Fig_lab[6+count], fontproperties=font, fontsize = fsize) # forcing
        else:
            sub7.text(2010 - 5, 140, Fig_lab[6+count], fontproperties=font, fontsize = fsize) # forcing
        
        for file_index in xrange(len(file_list)):
            filename = file_list[file_index]
            file2 = open(filename+rcp+"/CORAL-"+rcp+"-"+Locations[z]+".dat", "r")
            HOSTSet1 = load(file2)
            file2.close()
            
            file3 = open(filename+rcp+"/TRAIT-"+rcp+"-"+Locations[z]+".dat", "r")
            TRAITSet1 = load(file3)
            file3.close()
            
            file4 =  open(filename+rcp+"/SYMB-"+rcp+"-"+Locations[z]+".dat", "r")
            SYMBSet1 = load(file4)
            file4.close()
            
            HOST = HOSTSet1
            SYMB = SYMBSet1
            TRAIT = TRAITSet1
        
            MeanlossCoralBiomass = []
            if file_index == 0 and z == 0:
                N_index = reg_N_index[z]
                Host = HOST[N_index]
                Trait = TRAIT[N_index]
                Symb = SYMB[N_index]  
                compare0 = (time<=2005)*(time>=1986)
                
                PastHost = sum(Host[compare0])/sum(compare0)
                PastTrait = sum(Trait[compare0])/sum(compare0)
                PastSymb = sum(Symb[compare0])/sum(compare0)
                
                sub1.plot(time, 100*Trait/PastTrait, linewidth = 3, color = Color_list[v])                 
                sub4.plot(time, 100*Host/PastHost, linewidth = 3, color = Color_list[v])                
                sub7.plot(time, 100*Symb/PastSymb, linewidth = 3, color = Color_list[v], label = RCP_title[v])
                
                compare1 = (time<=2100)*(time>=2081)     
                FutureHost = sum(Host[compare1])/sum(compare1)
                MeanlossCoralBiomass.append((FutureHost-PastHost)/PastHost)
                PerChange = mean(array(MeanlossCoralBiomass))*100
                print rcp, Locations[z], PerChange, "N = ", rawNum_GBR[N_index]*scale          
            elif file_index == 0 and z == 1:
                N_index = reg_N_index[z]
                Host = HOST[N_index]
                Trait = TRAIT[N_index]
                Symb = SYMB[N_index]
                compare0 = (time<=2005)*(time>=1986)
                
                PastHost = sum(Host[compare0])/sum(compare0)
                PastTrait = sum(Trait[compare0])/sum(compare0)
                PastSymb = sum(Symb[compare0])/sum(compare0)
                
                sub1.plot(time, 100*Trait/PastTrait, linewidth = 3, color = Color_list[v]) 
                
                sub4.plot(time, 100*Host/PastHost, linewidth = 3, color = Color_list[v])
                
                sub7.plot(time, 100*Symb/PastSymb, linewidth = 3, color = Color_list[v], label = RCP_title[v])
                
                compare1 = (time<=2100)*(time>=2081)     
                FutureHost = sum(Host[compare1])/sum(compare1)
                MeanlossCoralBiomass.append((FutureHost-PastHost)/PastHost)
                PerChange = mean(array(MeanlossCoralBiomass))*100
                print rcp, Locations[z], PerChange, "N = ", rawNum_SEA[N_index]*scale       
            elif file_index == 0 and z == 2:
                N_index = reg_N_index[z]
                Host = HOST[N_index]
                Trait = TRAIT[N_index]
                Symb = SYMB[N_index] 
                compare0 = (time<=2005)*(time>=1986)
                
                PastHost = sum(Host[compare0])/sum(compare0)
                PastTrait = sum(Trait[compare0])/sum(compare0)
                PastSymb = sum(Symb[compare0])/sum(compare0)
                
                sub1.plot(time, 100*Trait/PastTrait, linewidth = 3, color = Color_list[v]) 
                
                sub4.plot(time, 100*Host/PastHost, linewidth = 3, color = Color_list[v])
                
                sub7.plot(time, 100*Symb/PastSymb, linewidth = 3, color = Color_list[v], label = RCP_title[v])
                
                compare1 = (time<=2100)*(time>=2081)     
                FutureHost = sum(Host[compare1])/sum(compare1)
                MeanlossCoralBiomass.append((FutureHost-PastHost)/PastHost)
                PerChange = mean(array(MeanlossCoralBiomass))*100
                print rcp, Locations[z], PerChange, "N = ", rawNum_CAR[N_index]*scale          
                print rcp, Locations[z], PerChange, "N = ", rawNum_CAR[N_index]*scale             
        if count in (3, ):
            sub1.tick_params(axis = "y", direction = "in", labelsize = fsize2)
            sub1.set_yticks(list(TraitTicks)) # GBR and SEA
            sub1.set_yticklabels(list(["%d"%TraitTicks[s] for s in xrange(len(TraitTicks))]))
            part1.tick_params(axis = "y", direction = "in", labelsize = fsize2) 
            part1.set_yticks(TraitTicks)
            part1.set_yticklabels([" "%d for d in TraitTicks])
            
            sub4.tick_params(axis = "y", direction = "in", labelsize = fsize2)
            sub4.set_yticks(list(hostTicks))
            sub4.set_yticklabels(["$0$"]+list(["%.d"%hostTicks[k] for k in xrange(1, len(hostTicks))]))
            part4.tick_params(axis = "y", direction = "in", labelsize = fsize2) 
            part4.set_yticks(hostTicks)
            part4.set_yticklabels([" "%d for d in hostTicks])
            
            sub7.tick_params(axis = "y", direction = "in", labelsize = fsize2)
            sub7.set_yticks(list(Symbticks))
            sub7.set_yticklabels(["$0$"]+list(["%d"%Symbticks[s] for s in xrange(1, len(Symbticks))]))
            part7.tick_params(axis = "y", direction = "in", labelsize = fsize2) 
            part7.set_yticks(Symbticks)
            part7.set_yticklabels([" "%d for d in Symbticks])
        else:
            sub1.tick_params(axis = "y", direction = "in", labelsize = fsize2)
            sub1.set_yticks(list(TraitTicks))
            sub1.set_yticklabels([" "]+list([" " for s in xrange(1, len(TraitTicks))]))
            part1.tick_params(axis = "y", direction = "in", labelsize = fsize2) 
            part1.set_yticks(TraitTicks)
            part1.set_yticklabels([" "%d for d in TraitTicks])
            
            sub4.tick_params(axis = "y", direction = "in", labelsize = fsize2)
            sub4.set_yticks(list(hostTicks))
            sub4.set_yticklabels([" "]+list([" " for k in xrange(1, len(hostTicks))]))
            part4.tick_params(axis = "y", direction = "in", labelsize = fsize2) 
            part4.set_yticks(hostTicks)
            part4.set_yticklabels([" "%d for d in hostTicks])
            
            sub7.tick_params(axis = "y", direction = "in", labelsize = fsize2)
            sub7.set_yticks(list(Symbticks))
            sub7.set_yticklabels([" "]+list([" " for s in xrange(1, len(Symbticks))]))
            part7.tick_params(axis = "y", direction = "in", labelsize = fsize2) 
            part7.set_yticks(Symbticks)
            part7.set_yticklabels([" "%d for d in Symbticks])           
        sub1.set_ylim((100, 103))
        sub1.set_xlim((startTime, max(time0))) 
        part1.set_ylim((100, 103))
        part1.set_xlim((startTime, max(time0))) 
        
        sub4.set_xlim((startTime, max(time0))) 
        sub4.set_ylim((40, 140))
        part4.set_ylim((40, 140))
        sub4.set_xlim((startTime, max(time0))) 
        
        sub7.set_ylim((40, 140))
        part7.set_ylim((40, 140)) 
        sub7.set_xlim((startTime, max(time0))) 
        sub7.set_xlabel("Years", fontsize=fsize)            
    count +=1
"""

# Plotting Spine up, although, in the end I did not need this for the manuscript so it might give some error because I did not update it 
Color_list = [(0.651, 0.325, 0.529), (0.839+0.025, 0.60+0.05, 0.20), (0.839+0.16, 0.363, 0.35)]
"""
for z in xrange(len(Locations)):
    for v in xrange(1):#len(RCP)):
        rcp = RCP[v]
        file0 = open("Years-"+Locations[z]+"-"+rcp+"-MPI"+".dat", "r")
        time0 = load(file0)
        file0.close()
        time = concatenate((arange(min(time0)-AddTime, min(time0), 1), time0))   # time are already given in year
        file1 = open("SST-"+Locations[z]+"-"+rcp+"-MPI"+".dat", "r")
        TempNS = load(file1)
        file1.close()
            
        sub1 = plt.subplot(4, 3, 1+count)
        plt.title(Locations_title[z], fontsize = fsize, fontproperties = font)
        TraitTicks = array([0, 20, 40, 60, 80, 100])/100
        plt.xticks([0, 955, 2016], ["", "", ""], fontsize = 10)
        #plt.xticks([2016, 2100], ["", "", ""], fontsize = 10)

        plt.xlim((min(time), 2016))# min(time0))) 
        #plt.xlim((2016, max(time)))       
            
        if count == 3:
            plt.yticks(list(TraitTicks), ["$0$"]+list(["%.1f"%TraitTicks[s] for s in xrange(1, len(TraitTicks))])) # GBR and SEA
            plt.ylabel("Normalized \n Trait $U$", fontsize = fsize)
            plt.text(min(time) - 200, 1.00, Fig_lab[count], fontproperties=font,  fontsize = fsize)
        else:
            plt.yticks(list(TraitTicks), [" "]+list([" " for s in xrange(1, len(TraitTicks))]))
            plt.text(min(time) - 50, 1.00, Fig_lab[count], fontproperties=font,  fontsize = fsize)

        plt.ylim((0, 1.00))
            
        plt.tick_params(labelsize=fsize2)
        sub4 = plt.subplot(4, 3, 4+count)
        plt.xticks([0, 955 , 2016], ["", "", ""], fontsize = 10)
        #plt.xticks([2016, 2100], ["", "", ""], fontsize = 10)

        plt.xlim((min(time), 2016))# min(time0))) 
        #plt.xlim((2016, max(time)))       
                  
        hostTicks = array([0, 20, 40, 60, 80, 100])/100 
        plt.tick_params(labelsize=fsize2)
        if count == 3:
            plt.yticks(list(hostTicks), ["$0$"]+list(["%.1f"%hostTicks[k] for k in xrange(1, len(hostTicks))]), fontsize = fsize2)
            #plt.ylabel("Coral $C$ \n ($\%$ to carrying capacity)", fontsize = fsize)
            #plt.ylabel("Coral $C$ \n ($\%$ of $K_C$)", fontsize = fsize)
            plt.ylabel("Normalized \n Coral Biomass $C$", fontsize = fsize)
            plt.text(min(time) - 200, 1.00, Fig_lab[3+count],fontproperties=font, fontsize = fsize) # forcing
        else: 
            plt.yticks(list(hostTicks), [" "]+list([" " for k in xrange(1, len(hostTicks))]))
            plt.text(min(time) - 50, 1.00, Fig_lab[3+count],fontproperties=font, fontsize = fsize) # forcing
        
        plt.ylim((0,1.00))
        
        sub7 = plt.subplot(4, 3, 7+count)
        #plt.xticks([0, 955 , 2016], fontsize = fsize2)
        #plt.xticks([2016, 2100], fontsize = 10)

        plt.xlim((min(time), 2016))# min(time0))) 
        #plt.xlim((2016, max(time)))       

        plt.xlabel("Years", fontsize=fsize)
        Symbticks = array([0, 20, 40, 60, 80, 100])/100
        
        if count==3:
            plt.yticks(list(Symbticks), ["$0$"]+list(["%.1f"%Symbticks[s] for s in xrange(1, len(Symbticks))]))
            plt.ylabel("Normalized \n Symbiont Biomass $S$", fontsize = fsize)
            plt.text(min(time) - 200, 1.00, Fig_lab[6+count], fontproperties=font, fontsize = fsize) # forcing
        else:
            plt.yticks(list(Symbticks*1e14), [" "]+list([" " for s in xrange(1, len(Symbticks))]))
            plt.text(min(time) - 50, 1.00, Fig_lab[6+count], fontproperties=font, fontsize = fsize) # forcing
        
        plt.ylim((0, 1.00))
                
        plt.tick_params(labelsize=fsize2)
            
        for file_index in xrange(len(file_list)):
            filename = file_list[file_index]
            file2 = open(filename+rcp+"/CORAL-"+rcp+"-"+Locations[z]+".dat", "r")
            HOSTSet1 = load(file2)
            file2.close()
            
            file3 = open(filename+rcp+"/TRAIT-"+rcp+"-"+Locations[z]+".dat", "r")
            TRAITSet1 = load(file3)
            file3.close()
            
            file4 =  open(filename+rcp+"/SYMB-"+rcp+"-"+Locations[z]+".dat", "r")
            SYMBSet1 = load(file4)
            file4.close()
            
            HOST = HOSTSet1
            SYMB = SYMBSet1
            TRAIT = TRAITSet1
            
            MeanlossCoralBiomass = []
                        
            N_List = (scale)*rawNum_list[file_index]
            
            if z == 0:
                display = len(N_List) - 8
            else:
                display = len(N_List) - 9
            for i in xrange(display):
                Host = HOST[i]
                Trait = TRAIT[i]
                Symb = SYMB[i]     
                compare0 = (time<=2005)*(time>=1986)
                PastHost = sum(Host[compare0])/sum(compare0)
                PastTrait = sum(Trait[compare0])/sum(compare0)
                PastSymb = sum(Symb[compare0])/sum(compare0)
                #sub1.plot(time, 100*Trait/PastTrait, linewidth = 0.75, color = Color_list[v], alpha = 0.35) 
                sub1.plot(time, Trait/8e-5, linewidth = 0.75, color = Color_list[v], alpha = 0.25)
                #sub4.plot(time, 100*Host/PastHost, linewidth = 0.75, color = Color_list[v], alpha = 0.35)
                sub4.plot(time, Host/K_C, linewidth = 0.75, color = Color_list[v], alpha = 0.25)                
                #sub7.plot(time, 100*Symb/PastSymb, linewidth = 0.75, color = Color_list[v], alpha = 0.35)
                sub7.plot(time, Symb/(Ksmax*K_C), linewidth = 0.75, color = Color_list[v], alpha = 0.25)
            
            if file_index == 0 and z == 0:
                N_index = reg_N_index[z]
                print Locations[z], filename
                Host = HOST[N_index]
                Trait = TRAIT[N_index]
                Symb = SYMB[N_index]  
                compare0 = (time<=2005)*(time>=1986)
                
                PastHost = sum(Host[compare0])/sum(compare0)
                PastTrait = sum(Trait[compare0])/sum(compare0)
                PastSymb = sum(Symb[compare0])/sum(compare0)
                
                #sub1.plot(time, 100*Trait/PastTrait, linewidth = 3, color = Color_list[v]) 
                sub1.plot(time, Trait/8e-5, linewidth = 3, color = Color_list[v])
                #sub1.fill_between(time, 100*lower_bound_Trait/PastTrait, 100*upper_bound_Trait/PastTrait, facecolor= Color_list[v], alpha=0.25)
                
                #sub4.plot(time, 100*Host/PastHost, linewidth = 3, color = Color_list[v])
                sub4.plot(time, Host/K_C, linewidth = 3, color = Color_list[v])
                #sub4.fill_between(time, 100*lower_bound_Host/PastHost, 100*upper_bound_Host/PastHost, facecolor= Color_list[v], alpha=0.25)
                
                #sub7.plot(time, 100*Symb/PastSymb, linewidth = 3, color = Color_list[v], label = RCP_title[v])
                sub7.plot(time, Symb/(Ksmax*K_C), linewidth = 3, color = Color_list[v], label = RCP_title[v])
                #sub7.fill_between(time, 100*lower_bound_Symb/PastSymb, 100*upper_bound_Symb/PastSymb, facecolor= Color_list[v], alpha=0.25)
                
                compare1 = (time<=2100)*(time>=2081)     
                FutureHost = sum(Host[compare1])/sum(compare1)
                MeanlossCoralBiomass.append((FutureHost-PastHost)/PastHost)
                PerChange = mean(array(MeanlossCoralBiomass))*100
                print rcp, Locations[z], PerChange         
            elif file_index == 0 and z == 1:
                N_index = reg_N_index[z]
                print Locations[z], filename
                Host = HOST[N_index]
                Trait = TRAIT[N_index]
                Symb = SYMB[N_index]
                compare0 = (time<=2005)*(time>=1986)
                
                PastHost = sum(Host[compare0])/sum(compare0)
                PastTrait = sum(Trait[compare0])/sum(compare0)
                PastSymb = sum(Symb[compare0])/sum(compare0)
                
                #sub1.plot(time, 100*Trait/PastTrait, linewidth = 3, color = Color_list[v]) 
                sub1.plot(time, Trait/8e-5, linewidth = 3, color = Color_list[v]) 

                #sub4.plot(time, 100*Host/PastHost, linewidth = 3, color = Color_list[v])
                sub4.plot(time, Host/K_C, linewidth = 3, color = Color_list[v])

                #sub7.plot(time, 100*Symb/PastSymb, linewidth = 3, color = Color_list[v], label = RCP_title[v])
                sub7.plot(time, Symb/(Ksmax * K_C), linewidth = 3, color = Color_list[v], label = RCP_title[v])

                compare1 = (time<=2100)*(time>=2081)     
                FutureHost = sum(Host[compare1])/sum(compare1)
                MeanlossCoralBiomass.append((FutureHost-PastHost)/PastHost)
                PerChange = mean(array(MeanlossCoralBiomass))*100
                print rcp, Locations[z], PerChange         
            elif file_index == 0 and z == 2:
                N_index = reg_N_index[z]
                print Locations[z], filename
                Host = HOST[N_index]
                Trait = TRAIT[N_index]
                Symb = SYMB[N_index] 
                compare0 = (time<=2005)*(time>=1986)
                
                PastHost = sum(Host[compare0])/sum(compare0)
                PastTrait = sum(Trait[compare0])/sum(compare0)
                PastSymb = sum(Symb[compare0])/sum(compare0)
                
                #sub1.plot(time, 100*Trait/PastTrait, linewidth = 3, color = Color_list[v]) 
                sub1.plot(time, Trait/8e-5, linewidth = 3, color = Color_list[v]) 

                #sub4.plot(time, 100*Host/PastHost, linewidth = 3, color = Color_list[v])
                sub4.plot(time, Host/K_C, linewidth = 3, color = Color_list[v])

                #sub7.plot(time, 100*Symb/PastSymb, linewidth = 3, color = Color_list[v], label = RCP_title[v])
                sub7.plot(time, Symb/(Ksmax * K_C), linewidth = 3, color = Color_list[v], label = RCP_title[v])
                
                compare1 = (time<=2100)*(time>=2081)     
                FutureHost = sum(Host[compare1])/sum(compare1)
                MeanlossCoralBiomass.append((FutureHost-PastHost)/PastHost)
                PerChange = mean(array(MeanlossCoralBiomass))*100
                print rcp, Locations[z], PerChange  
    
    count +=1
"""  

# Plot parameter sensitivity Supplementary Fig. 9
"""
scale = (12**2)*1e-11

rawNum_GBR_orig = arange(0.01, 0.1, 0.00005)
rawNum_SEA_orig = arange(0.01, 0.1, 0.00005)
rawNum_CAR_orig = arange(0.01, 0.1, 0.00005) 

#  Speed of adapations specific for each region for main results
GBR_N_index_orig = 920 # index in rawNum_GBR  0.056
SEA_N_index_orig = 330 # index in rawNum_SEA  0.0265
CAR_N_index_orig = 275 # index in rawNum_CAR  0.02375
reg_N_index_orig = [GBR_N_index_orig, SEA_N_index_orig, CAR_N_index_orig]

# Runs in Sensitivity_N (specifically for standard runs with N) # This runs should be generated with Model-RCP-ode-yearly.py
rawNum_GBR_0 = concatenate((arange(min(rawNum_GBR_orig), rawNum_GBR_orig[GBR_N_index_orig], 0.0005), array([0.75*rawNum_GBR_orig[GBR_N_index_orig]]), array([rawNum_GBR_orig[GBR_N_index_orig]]), array([1.25*rawNum_GBR_orig[GBR_N_index_orig]]), arange(rawNum_GBR_orig[GBR_N_index_orig]+0.0005, max(rawNum_GBR_orig), 0.0005)))
rawNum_SEA_0 = concatenate((arange(min(rawNum_SEA_orig), rawNum_SEA_orig[SEA_N_index_orig], 0.0005), array([0.75*rawNum_SEA_orig[SEA_N_index_orig]]), array([rawNum_SEA_orig[SEA_N_index_orig]]), array([1.25*rawNum_SEA_orig[SEA_N_index_orig]]), arange(rawNum_SEA_orig[SEA_N_index_orig]+0.0005, max(rawNum_SEA_orig), 0.0005)))
rawNum_CAR_0 = concatenate((arange(min(rawNum_CAR_orig), rawNum_CAR_orig[CAR_N_index_orig], 0.0005), array([0.75*rawNum_CAR_orig[CAR_N_index_orig]]), array([rawNum_CAR_orig[CAR_N_index_orig]]), array([1.25*rawNum_CAR_orig[CAR_N_index_orig]]), arange(rawNum_CAR_orig[CAR_N_index_orig]+0.0005, max(rawNum_CAR_orig), 0.0005)))

# Runs in Sensitivity_N/Sensitivity (generated with Sensitivity-RCP-yearly.py) and Sensitivity-N/Senstivity-Fix-other-Params an +/-25 % in N (generated with Model-RCP-ode-yearly.py)
rawNum_GBR = concatenate((array([0.75*rawNum_GBR_orig[GBR_N_index_orig]]), array([rawNum_GBR_orig[GBR_N_index_orig]]), array([1.25*rawNum_GBR_orig[GBR_N_index_orig]])))
rawNum_SEA = concatenate((array([0.75*rawNum_SEA_orig[SEA_N_index_orig]]), array([rawNum_SEA_orig[SEA_N_index_orig]]), array([1.25*rawNum_SEA_orig[SEA_N_index_orig]])))
rawNum_CAR = concatenate((array([0.75*rawNum_CAR_orig[CAR_N_index_orig]]), array([rawNum_CAR_orig[CAR_N_index_orig]]), array([1.25*rawNum_CAR_orig[CAR_N_index_orig]]))) 

# Indexes corresponding to specific speed of adaptation including the -25% and +25% 
GBR_N_index_minus = 0 #len(arange(min(rawNum_GBR_orig), rawNum_GBR_orig[GBR_N_index_orig], 0.0005))
GBR_N_index = 1
GBR_N_index_plus = 2

SEA_N_index_minus = 0
SEA_N_index = 1
SEA_N_index_plus = 2

CAR_N_index_minus = 0
CAR_N_index = 1
CAR_N_index_plus = 2

reg_N_index_minus = [GBR_N_index_minus, SEA_N_index_minus, CAR_N_index_minus]
reg_N_index = [GBR_N_index, SEA_N_index, CAR_N_index]
reg_N_index_plus = [GBR_N_index_plus, SEA_N_index_plus, CAR_N_index_plus]

# Regional coral carrying capacity
K_C_GBR = 438718.902336e10 # in cm^2
K_C_SEA = 1191704.68901e10 # in cm^2
K_C_CAR = 190374.697987e10  # in cm^2
K_C_List = [K_C_GBR, K_C_SEA, K_C_CAR]

file_list = ["Sensitivity-N/"]

# + or - 25% change
ParamsPlus= ["Gmax-Plus", "a-Plus", "b-Plus", "KC-Plus", "Ksmax-Plus", "MC-Plus", "alpha-Plus", "r-Plus", "beta-Plus", "GammaH-Plus"]
ParamsMinus= ["Gmax-Minus", "a-Minus", "b-Minus", "KC-Minus", "Ksmax-Minus", "MC-Minus", "alpha-Minus", "r-Minus", "beta-Minus", "GammaH-Minus"]
Params = ["$G_{max}$", "$a$", "$b$", "$K_C$", "$K_{smax}$", "$M_C$", r"$\alpha$", "$r$", r"$\beta$", r"$\Gamma_h$"]
NumP = linspace(1.5, 30, len(Params) + 1) 
ChosenStart = -100 # comparing betweeen year 2000 and 2100
width = 0.6
count = 1

for z in xrange(len(Locations)):
    for v in xrange(len(RCP)):
        sub = plt.subplot(3, 3, count)
        rcp = RCP[v]
        file0 = open("Years-"+Locations[z]+"-"+rcp+"-MPI"+".dat", "r")
        time0 = load(file0)
        file0.close()
        time = concatenate((arange(min(time0)-AddTime, min(time0), 1), time0))   # time are already given in year
        file1 = open("SST-"+Locations[z]+"-"+rcp+"-MPI"+".dat", "r")
        TempNS = load(file1)
        file1.close()
        
        for file_index in xrange(len(file_list)):
            filename = file_list[file_index]
            file2 = open(filename+rcp+"/CORAL-"+rcp+"-"+Locations[z]+".dat", "r")
            HOSTSet1 = load(file2)
            file2.close()
            
            file3 = open(filename+rcp+"/TRAIT-"+rcp+"-"+Locations[z]+".dat", "r")
            TRAITSet1 = load(file3)
            file3.close()
            
            file4 =  open(filename+rcp+"/SYMB-"+rcp+"-"+Locations[z]+".dat", "r")
            SYMBSet1 = load(file4)
            file4.close()
            
            HOST = HOSTSet1
            SYMB = SYMBSet1
            TRAIT = TRAITSet1
            TraitTicks = array([0., 0.5, 1, 1.5]) # for GBR, SEA
            
            MeanlossCoralBiomass = []
            
            ResCoralPlus = zeros(len(ParamsPlus))
            ResSymbPlus = zeros(len(ParamsPlus))
            ResTraitPlus = zeros(len(ParamsPlus))
        
            ResCoralMinus = zeros(len(ParamsPlus))
            ResSymbMinus = zeros(len(ParamsPlus))
            ResTraitMinus = zeros(len(ParamsPlus))
            if file_index == 0 and z == 0:
                N_index = reg_N_index[z]
                print Locations[z], filename, rawNum_GBR[N_index], rawNum_GBR_orig[reg_N_index_orig[z]]
                Host = HOST[list(rawNum_GBR_0).index(rawNum_GBR_orig[GBR_N_index_orig])]
                Trait = TRAIT[list(rawNum_GBR_0).index(rawNum_GBR_orig[GBR_N_index_orig])]
                Symb = SYMB[list(rawNum_GBR_0).index(rawNum_GBR_orig[GBR_N_index_orig])] 
                ResCoralPlusDiff = zeros(len(ParamsPlus)+1)
                ResCoralMinusDiff = zeros(len(ParamsPlus)+1)  
                for ind in xrange(len(Params)):
                    changePlus = 1.25
                    changeMinus = 0.75
                    K_C_Reg = K_C_List[z]
                    if Params[ind] == "$K_C$":
                        K_C_plus =  changePlus*K_C_Reg
                        K_C_minus = changeMinus*K_C_Reg
                    else:
                        K_C_plus =  K_C_Reg
                        K_C_minus = K_C_Reg
                    fileCoral = open(filename+rcp+"/Sensitivity/CORAL-"+rcp+"-"+Locations[z]+"-"+ParamsPlus[ind]+".dat", "r")
                    fileTrait = open(filename+rcp+"/Sensitivity/CORAL-"+rcp+"-"+Locations[z]+"-"+ParamsPlus[ind]+".dat", "r")
                    fileSymb = open(filename+rcp+"/Sensitivity/CORAL-"+rcp+"-"+Locations[z]+"-"+ParamsPlus[ind]+".dat", "r")
                    Coral_plus = load(fileCoral)
                    Trait_plus = load(fileTrait)
                    Symb_plus = load(fileSymb)
                    fileCoral.close()
                    fileTrait.close()
                    fileSymb.close()
                    
                    fileCoral = open(filename+rcp+"/Sensitivity/CORAL-"+rcp+"-"+Locations[z]+"-"+ParamsMinus[ind]+".dat", "r")
                    fileTrait = open(filename+rcp+"/Sensitivity/CORAL-"+rcp+"-"+Locations[z]+"-"+ParamsMinus[ind]+".dat", "r")
                    fileSymb = open(filename+rcp+"/Sensitivity/CORAL-"+rcp+"-"+Locations[z]+"-"+ParamsMinus[ind]+".dat", "r")
                    Coral_minus = load(fileCoral)
                    Trait_minus = load(fileTrait)
                    Symb_minus = load(fileSymb)
                    fileCoral.close()
                    fileTrait.close()
                    fileSymb.close()    
                      
                    ResCoralPlusDiff[ind] = 100*(mean(Coral_plus[N_index, ChosenStart:]) - mean(Host[ChosenStart:]))/mean(Host[ChosenStart:])
                    ResCoralMinusDiff[ind] = 100*(mean(Coral_minus[N_index, ChosenStart:]) - mean(Host[ChosenStart:]))/mean(Host[ChosenStart:])
                   
                # Sensitivity to N
                fileCoral = open("Sensitivity-N/Senstivity-Fix-other-Params/"+rcp+"/CORAL-"+rcp+"-"+Locations[z]+".dat", "r")
                fileTrait = open("Sensitivity-N/Senstivity-Fix-other-Params/"+rcp+"/TRAIT-"+rcp+"-"+Locations[z]+".dat", "r")
                fileSymb = open("Sensitivity-N/Senstivity-Fix-other-Params/"+rcp+"/SYMB-"+rcp+"-"+Locations[z]+".dat", "r")
                Coral_N = load(fileCoral)
                Trait_N = load(fileTrait)
                Symb_N = load(fileSymb)
                fileCoral.close()
                fileTrait.close()
                fileSymb.close()
                
                ResCoralPlusDiff[-1] = 100*(mean(Coral_N[reg_N_index_plus[z], ChosenStart:]) - mean(Host[ChosenStart:]))/mean(Host[ChosenStart:])
                ResCoralMinusDiff[-1] = 100*(mean(Coral_N[reg_N_index_minus[z], ChosenStart:]) - mean(Host[ChosenStart:]))/mean(Host[ChosenStart:])
                
                sub.plot(NumP, zeros(len(NumP)), linewidth = 1, color = "black")                  
                sub.bar(NumP, ResCoralPlusDiff, width, color = (0.463, 0.647, 0.647), label = "$+25\%$")  
                sub.bar(NumP+width, ResCoralMinusDiff, width, color = (0.008, 0.22, 0.278), label = "$-25\%$") 
            elif file_index == 0 and z == 1:
                N_index = reg_N_index[z]
                print Locations[z], filename, rawNum_SEA[N_index], rawNum_SEA_orig[reg_N_index_orig[z]]
                Host = HOST[list(rawNum_SEA_0).index(rawNum_SEA_orig[SEA_N_index_orig])]
                Trait = TRAIT[list(rawNum_SEA_0).index(rawNum_SEA_orig[SEA_N_index_orig])]
                Symb = SYMB[list(rawNum_SEA_0).index(rawNum_SEA_orig[SEA_N_index_orig])]   
                ResCoralPlusDiff = zeros(len(ParamsPlus)+1)
                ResCoralMinusDiff = zeros(len(ParamsPlus)+1)
                for ind in xrange(len(Params)):
                    changePlus = 1.25 
                    changeMinus = 0.75
                    K_C_Reg = K_C_List[z]
                    if Params[ind] == "$K_C$":
                        K_C_plus =  changePlus*K_C_Reg
                        K_C_minus = changeMinus*K_C_Reg
                    else:
                        K_C_plus =  K_C_Reg
                        K_C_minus = K_C_Reg
                    fileCoral = open(filename+rcp+"/Sensitivity/CORAL-"+rcp+"-"+Locations[z]+"-"+ParamsPlus[ind]+".dat", "r")
                    fileTrait = open(filename+rcp+"/Sensitivity/CORAL-"+rcp+"-"+Locations[z]+"-"+ParamsPlus[ind]+".dat", "r")
                    fileSymb = open(filename+rcp+"/Sensitivity/CORAL-"+rcp+"-"+Locations[z]+"-"+ParamsPlus[ind]+".dat", "r")
                    Coral_plus = load(fileCoral)
                    Trait_plus = load(fileTrait)
                    Symb_plus = load(fileSymb)
                    fileCoral.close()
                    fileTrait.close()
                    fileSymb.close()
                    
                    fileCoral = open(filename+rcp+"/Sensitivity/CORAL-"+rcp+"-"+Locations[z]+"-"+ParamsMinus[ind]+".dat", "r")
                    fileTrait = open(filename+rcp+"/Sensitivity/CORAL-"+rcp+"-"+Locations[z]+"-"+ParamsMinus[ind]+".dat", "r")
                    fileSymb = open(filename+rcp+"/Sensitivity/CORAL-"+rcp+"-"+Locations[z]+"-"+ParamsMinus[ind]+".dat", "r")
                    Coral_minus = load(fileCoral)
                    Trait_minus = load(fileTrait)
                    Symb_minus = load(fileSymb)
                    fileCoral.close()
                    fileTrait.close()
                    fileSymb.close()
               
                    ResCoralPlusDiff[ind] = 100*(mean(Coral_plus[N_index, ChosenStart:]) - mean(Host[ChosenStart:]))/mean(Host[ChosenStart:])
                    ResCoralMinusDiff[ind] = 100*(mean(Coral_minus[N_index, ChosenStart:]) - mean(Host[ChosenStart:]))/mean(Host[ChosenStart:])
                   
                # Sensitivity to N
                fileCoral = open("Sensitivity-N/Senstivity-Fix-other-Params/"+rcp+"/CORAL-"+rcp+"-"+Locations[z]+".dat", "r")
                fileTrait = open("Sensitivity-N/Senstivity-Fix-other-Params/"+rcp+"/TRAIT-"+rcp+"-"+Locations[z]+".dat", "r")
                fileSymb = open("Sensitivity-N/Senstivity-Fix-other-Params/"+rcp+"/SYMB-"+rcp+"-"+Locations[z]+".dat", "r")
                Coral_N = load(fileCoral)
                Trait_N = load(fileTrait)
                Symb_N = load(fileSymb)
                fileCoral.close()
                fileTrait.close()
                fileSymb.close()
                
                ResCoralPlusDiff[-1] = 100*(mean(Coral_N[reg_N_index_plus[z], ChosenStart:]) - mean(Host[ChosenStart:]))/mean(Host[ChosenStart:])
                ResCoralMinusDiff[-1] = 100*(mean(Coral_N[reg_N_index_minus[z], ChosenStart:]) - mean(Host[ChosenStart:]))/mean(Host[ChosenStart:])
                
                sub.plot(NumP, zeros(len(NumP)), linewidth = 1, color = "black")                  
                sub.bar(NumP, ResCoralPlusDiff, width, color = (0.463, 0.647, 0.647), label = "$+25\%$")  
                sub.bar(NumP+width, ResCoralMinusDiff, width, color = (0.008, 0.22, 0.278), label = "$-25\%$")   
            elif file_index == 0 and z == 2:
                N_index = reg_N_index[z]
                print Locations[z], filename, rawNum_CAR[N_index], rawNum_CAR_orig[reg_N_index_orig[z]]
                Host = HOST[list(rawNum_CAR_0).index(rawNum_CAR_orig[CAR_N_index_orig])]
                Trait = TRAIT[list(rawNum_CAR_0).index(rawNum_CAR_orig[CAR_N_index_orig])]
                Symb = SYMB[list(rawNum_CAR_0).index(rawNum_CAR_orig[CAR_N_index_orig])]  
                ResCoralPlusDiff = zeros(len(ParamsPlus)+1)
                ResCoralMinusDiff = zeros(len(ParamsPlus)+1)
                for ind in xrange(len(Params)):
                    changePlus = 1.25
                    changeMinus = 0.75
                    K_C_Reg = K_C_List[z]
                    if Params[ind] == "$K_C$":
                        K_C_plus =  changePlus*K_C_Reg
                        K_C_minus = changeMinus*K_C_Reg
                    else:
                        K_C_plus =  K_C_Reg
                        K_C_minus = K_C_Reg
                    fileCoral = open(filename+rcp+"/Sensitivity/CORAL-"+rcp+"-"+Locations[z]+"-"+ParamsPlus[ind]+".dat", "r")
                    fileTrait = open(filename+rcp+"/Sensitivity/CORAL-"+rcp+"-"+Locations[z]+"-"+ParamsPlus[ind]+".dat", "r")
                    fileSymb = open(filename+rcp+"/Sensitivity/CORAL-"+rcp+"-"+Locations[z]+"-"+ParamsPlus[ind]+".dat", "r")
                    Coral_plus = load(fileCoral)
                    Trait_plus = load(fileTrait)
                    Symb_plus = load(fileSymb)
                    fileCoral.close()
                    fileTrait.close()
                    fileSymb.close()
                    
                    fileCoral = open(filename+rcp+"/Sensitivity/CORAL-"+rcp+"-"+Locations[z]+"-"+ParamsMinus[ind]+".dat", "r")
                    fileTrait = open(filename+rcp+"/Sensitivity/CORAL-"+rcp+"-"+Locations[z]+"-"+ParamsMinus[ind]+".dat", "r")
                    fileSymb = open(filename+rcp+"/Sensitivity/CORAL-"+rcp+"-"+Locations[z]+"-"+ParamsMinus[ind]+".dat", "r")
                    Coral_minus = load(fileCoral)
                    Trait_minus = load(fileTrait)
                    Symb_minus = load(fileSymb)
                    fileCoral.close()
                    fileTrait.close()
                    fileSymb.close()
                                 
                    ResCoralPlusDiff[ind] = 100*(mean(Coral_plus[N_index, ChosenStart:]) - mean(Host[ChosenStart:]))/mean(Host[ChosenStart:])
                    ResCoralMinusDiff[ind] = 100*(mean(Coral_minus[N_index, ChosenStart:]) - mean(Host[ChosenStart:]))/mean(Host[ChosenStart:])
                
                # Sensitivity to N
                fileCoral = open("Sensitivity-N/Senstivity-Fix-other-Params/"+rcp+"/CORAL-"+rcp+"-"+Locations[z]+".dat", "r")
                fileTrait = open("Sensitivity-N/Senstivity-Fix-other-Params/"+rcp+"/TRAIT-"+rcp+"-"+Locations[z]+".dat", "r")
                fileSymb = open("Sensitivity-N/Senstivity-Fix-other-Params/"+rcp+"/SYMB-"+rcp+"-"+Locations[z]+".dat", "r")
                Coral_N = load(fileCoral)
                Trait_N = load(fileTrait)
                Symb_N = load(fileSymb)
                fileCoral.close()
                fileTrait.close()
                fileSymb.close()
                
                ResCoralPlusDiff[-1] = 100*(mean(Coral_N[reg_N_index_plus[z], ChosenStart:]) - mean(Host[ChosenStart:]))/mean(Host[ChosenStart:])
                ResCoralMinusDiff[-1] = 100*(mean(Coral_N[reg_N_index_minus[z], ChosenStart:]) - mean(Host[ChosenStart:]))/mean(Host[ChosenStart:])
                
                sub.plot(NumP, zeros(len(NumP)), linewidth = 1, color = "black")                  
                sub.bar(NumP, ResCoralPlusDiff, width, color = (0.463, 0.647, 0.647), label = "$+25\%$")  
                sub.bar(NumP+width, ResCoralMinusDiff, width, color = (0.008, 0.22, 0.278), label = "$-25\%$")  
        if count in (7, 8, 9):
            plt.xticks(NumP+(0.5)*width, Params+["$N$"], rotation = 65, fontsize = fsize2+2)
        else:
            plt.xticks(NumP+(0.5)*width, [" " for i in xrange(len(Params))], fontsize = fsize2, fontproperties = font)  
        if count in (1, 2, 3):
            plt.title(RCP_title[v], fontproperties = font, fontsize = fsize)
        if count in (1, 4, 7):
            sub.tick_params(axis = "y", direction = "in", pad = 2, labelsize = fsize2)
            sub.set_yticks((-125, -100, -75, -50, -25, 0, 25, 50, 75, 100, 125))
            #sub.set_yticklabels(("-125", "-100", "-75", "-25", "0", "25", "50", "75", "100", "125"))
            part = sub.twinx()
            part.tick_params(axis = "y", direction = "in", pad = 2, labelsize = fsize2)
            part.set_yticks((-125, -100, -75, -50, -25, 0, 25, 50, 75, 100, 125))
            part.set_yticklabels(("", "", "", "", "", "", "", "", "", "", ""))
            part.set_ylim((-125, 75))
            if z == 0:
                sub.text(-12, 105-50, Locations_title[z], fontproperties = font, fontsize = 13, rotation = "vertical") # fontsize = 16
            elif z == 1:
                sub.text(-12, 85-50, Locations_title[z], fontproperties = font, fontsize = 13, rotation = "vertical") # fontsize = 16
            else:
                sub.text(-12, 65-50, Locations_title[z], fontproperties = font, fontsize = 13, rotation = "vertical") # fontsize = 16
            sub.text(-6, 125-50, Fig_lab[count-1], fontproperties = font, fontsize = fsize)
            sub.set_ylabel("$\%$ change in mean \n coral biomass", fontsize = fsize2)
        else:
            sub.tick_params(axis = "y", direction = "in", pad = 2, labelsize = fsize2)
            sub.set_yticks((-125, -100, -75, -50, -25, 0, 25, 50, 75, 100, 125))
            sub.set_yticklabels(("", "", "", "", "", "", "", "", "", "", ""))
            part = sub.twinx()
            part.tick_params(axis = "y", direction = "in", pad = 2, labelsize = fsize2)
            part.set_yticks((-125, -100, -75, -50, -25, 0, 25, 50, 75, 100, 125))
            part.set_yticklabels(("", "", "", "", "", "", "", "", "", "", ""))
            part.set_ylim((-125, 75))
            sub.text(-2, 125-50, Fig_lab[count-1], fontproperties = font, fontsize = 13)

        sub.set_ylim((-125, 75))   
        
        if count == 1:
            sub.legend(loc="best", fontsize = fsize2, ncol = 2, frameon = False) 
       
        count+=1
   
"""
# Sensitivity with respect to speed of adaptation  Supplementary Fig. 5 and 6                                                                                           
                                                                                      
count = 1
ChosenStart = -100 # year before 2100 to start comparison
# Regional coral carrying capacity
K_C_GBR = 438718.902336e10 # in cm^2
K_C_SEA = 1191704.68901e10 # in cm^2
K_C_CAR = 190374.697987e10  # in cm^2
K_C_List = [K_C_GBR, K_C_SEA, K_C_CAR]
file_list = ["Results-final/"]

# + or - 25% change
ParamsPlus= ["Gmax-Plus", "a-Plus", "b-Plus", "KC-Plus", "Ksmax-Plus", "MC-Plus", "alpha-Plus", "r-Plus", "beta-Plus", "GammaH-Plus"]
ParamsMinus= ["Gmax-Minus", "a-Minus", "b-Minus", "KC-Minus", "Ksmax-Minus", "MC-Minus", "alpha-Minus", "r-Minus", "beta-Minus", "GammaH-Minus"]
Params = ["$G_{max}$", "$a$", "$b$", "$K_C$", "$K_{smax}$", "$M_C$", r"$\alpha$", "$r$", r"$\beta$", r"$\Gamma_h$"]
NumP = linspace(1.5, 30, len(Params) + 1) 
col = [(1, 0.667, 0.667), (0.831, 0.416, 0.416), (0.502, 0.1, 0.1)]
ChosenStart = -100*12 # comparing betweeen year 2000 and 2100

cmx = mpl.cm
cmapC = mpl.cm.Set1
#cNorm = mpl.colors.Normalize(vmin=N_List.min(), vmax=N_List.max())
cNorm = mpl.colors.Normalize(vmin=0, vmax=len(Params))
scalarMap = cmx.ScalarMappable(norm=cNorm, cmap=cmapC)
# Sensitivity of results with respect to speed of adaptation N, 
rawNum_GBR_orig = arange(0.01, 0.1, 0.00005)
rawNum_SEA_orig = arange(0.01, 0.1, 0.00005)
rawNum_CAR_orig = arange(0.01, 0.1, 0.00005) 

# Speed of adapations specific for each region sensitivity # These were previous estimations, not the ones reported in the manuscript. 
# This is just to reduce the number of simulation, it was too late for me to redo all of everything with the newly estimated values of N, 
# but this is not important here because I generated the runs with newly estimated value of N separately.
GBR_N_index_prev = 100 # index in rawNum_GBR  0.0145
SEA_N_index_prev = 275 # index in rawNum_SEA  0.02375
CAR_N_index_prev = 250 # index in rawNum_CAR  0.0225

# Only for sensitivity simulations to reduce the number of simulations
rawNum_GBR = concatenate((arange(min(rawNum_GBR_orig), rawNum_GBR_orig[GBR_N_index_prev], 0.0005), array([0.75*rawNum_GBR_orig[GBR_N_index_prev]]), array([rawNum_GBR_orig[GBR_N_index_prev]]), array([1.25*rawNum_GBR_orig[GBR_N_index_prev]]), arange(rawNum_GBR_orig[GBR_N_index_prev]+0.0005, max(rawNum_GBR_orig), 0.0005)))
rawNum_SEA = concatenate((arange(min(rawNum_SEA_orig), rawNum_SEA_orig[SEA_N_index_prev], 0.0005), array([0.75*rawNum_SEA_orig[SEA_N_index_prev]]), array([rawNum_SEA_orig[SEA_N_index_prev]]), array([1.25*rawNum_SEA_orig[SEA_N_index_prev]]), arange(rawNum_SEA_orig[SEA_N_index_prev]+0.0005, max(rawNum_SEA_orig), 0.0005)))
rawNum_CAR = concatenate((arange(min(rawNum_CAR_orig), rawNum_CAR_orig[CAR_N_index_prev], 0.0005), array([0.75*rawNum_CAR_orig[CAR_N_index_prev]]), array([rawNum_CAR_orig[CAR_N_index_prev]]), array([1.25*rawNum_CAR_orig[CAR_N_index_prev]]), arange(rawNum_CAR_orig[CAR_N_index_prev]+0.0005, max(rawNum_CAR_orig), 0.0005)))

#  Speed of adapations specific for each region for main results
GBR_N_index = 920 # index in rawNum_GBR  0.056
SEA_N_index = 330 # index in rawNum_SEA  0.0265
CAR_N_index = 275 # index in rawNum_CAR  0.02375
reg_N_index = [GBR_N_index, SEA_N_index, CAR_N_index]

from scipy import interpolate   
for z in xrange(len(Locations)):
    for v in xrange(len(RCP)):            
        rcp = RCP[v] 
        #print Locations[z], rcp, count           
        sub = plt.subplot(3, 3, count)
        for ind in xrange(len(Params)):
            CORval = array([])
            N_full = array([])
            for file_index in xrange(len(file_list)):
                filename = file_list[file_index]
                file2 = open(filename+rcp+"/Sensitivity/CORAL-"+rcp+"-"+Locations[z]+"-"+ParamsPlus[ind]+".dat", "r")
                HOSTSet1 = load(file2)
                file2.close()
            
                file3 = open(filename+rcp+"/Sensitivity/TRAIT-"+rcp+"-"+Locations[z]+"-"+ParamsPlus[ind]+".dat", "r")
                TRAITSet1 = load(file3)
                file3.close()
            
                file4 =  open(filename+rcp+"/Sensitivity//SYMB-"+rcp+"-"+Locations[z]+"-"+ParamsPlus[ind]+".dat", "r")
                SYMBSet1 = load(file4)
                file4.close()
                
                change = 1.25 # 0.75 for ParamsMinus and 1.25 for ParamsPlus

                HOST = HOSTSet1
                SYMB = SYMBSet1
                TRAIT = TRAITSet1
                K_C = K_C_List[z]
                if file_index == 0 and z == 0:
                    rawNum_orig = rawNum_GBR_orig
                    rawNum = rawNum_GBR
                    N_List_orig = (scale)*rawNum_orig
                    N_List = (scale)*rawNum
                    sub.plot(N_List_orig[reg_N_index[z]]*ones(2), linspace(0, 1, 2), color = Color_list[0], linewidth = 4)
                elif file_index == 0 and z == 1:
                    rawNum_orig = rawNum_SEA_orig
                    rawNum = rawNum_SEA
                    N_List_orig = (scale)*rawNum_orig
                    N_List = (scale)*rawNum
                    sub.plot(N_List_orig[reg_N_index[z]]*ones(2), linspace(0, 1, 2), color = Color_list[0], linewidth = 4)
                elif file_index == 0 and z == 2:
                    rawNum_orig = rawNum_CAR_orig
                    rawNum = rawNum_CAR
                    N_List_orig = (scale)*rawNum_orig
                    N_List = (scale)*rawNum
                    sub.plot(N_List_orig[reg_N_index[z]]*ones(2), linspace(0, 1, 2), color = Color_list[0], linewidth = 4)
                print rawNum_orig[reg_N_index[z]], N_List_orig[reg_N_index[z]]
                ResCoral = zeros((len(Params), len(rawNum)))
                ResSymb = zeros((len(Params), len(rawNum)))
                ResTrait = zeros((len(Params), len(rawNum)))
            
                LocResCoral = zeros(len(rawNum))
                LocResSymb = zeros(len(rawNum))
                LocResTrait = zeros(len(rawNum))
                for i in xrange(len(rawNum)): 
                    if Params[ind] == "$K_C$":
                        LocResCoral[i] = mean(HOST[i][ChosenStart:])/(change*K_C)
                        LocResSymb[i] = mean(TRAIT[i][ChosenStart:])
                        LocResTrait[i] = mean(SYMB[i][ChosenStart:])  
                    else:
                        LocResCoral[i] = mean(HOST[i][ChosenStart:])/K_C
                        LocResSymb[i] = mean(TRAIT[i][ChosenStart:])
                        LocResTrait[i] = mean(SYMB[i][ChosenStart:])                    
                ResCoral[ind, :] = LocResCoral
                ResSymb[ind, :] = LocResSymb
                ResTrait[ind, :] = LocResTrait
                
                CORval = concatenate((CORval, ResCoral[ind, :]*((ind+3+1)/(len(Params)+3))))
                N_full = concatenate((N_full, N_List))
            if Params[ind] != r"$\Gamma_h$":
                colorval0 = scalarMap.to_rgba(ind+1)
            else:
                colorval0 = "black" 
            
            #  interpolate because unsorted values, not necessarily unique as well
            f = interpolate.interp1d(array(N_full), array(CORval), kind="cubic")
            N_new = linspace(min(N_full), max(N_full), 200)
            CORval_new = f(N_new)
            if count == 1:
                sub.plot(N_new, CORval_new, linewidth = 2, color = colorval0, label=Params[ind])#+ " (scaling = %.2f/$K_C$)"%((ind+3+1)/(len(Params)+3), ))
            else:
                sub.plot(N_new, CORval_new, linewidth = 2, color = colorval0)         
            if count not in (7, 8, 9):
                plt.xticks(array([1.44, 2, 3, 4, 5, 6, 7, 8, 9, 10])*1e-11, [" " for i in [1.44, 2, 3, 4, 5, 6, 7, 8, 9, 10]])
            else: 
                plt.xticks(array([1.44, 2, 3, 4, 5, 6, 7, 8, 9, 10])*1e-11, [""]+["%d"%N for N in [2, 3, 4, 5, 6, 7, 8, 9, 10]], fontsize=fsize2)
                plt.xlabel(r'Speed of acclimation $N$ $\times$ $10^{11}$', fontsize = fsize2)
            if count in (1, 4, 7):
                if z == 0:
                    plt.text(min(N_List) - 3e-11, 0.9, Locations_title[z], fontsize = fsize, fontproperties = font,  rotation = "vertical")
                if z == 1:
                    plt.text(min(N_List) - 3e-11, 0.85, Locations_title[z], fontsize = fsize, fontproperties = font,  rotation = "vertical")
                if z == 2:
                    plt.text(min(N_List) - 3e-11, 0.72, Locations_title[z], fontsize = fsize, fontproperties = font,  rotation = "vertical")    
                plt.text(min(N_List) - 1.2e-11, 1, Fig_lab[count-1], fontsize = fsize)
                hostTicks = array([0., 0.2, 0.4, 0.6, 0.8, 1.0])
                plt.yticks(list(hostTicks), ["$0$"]+list(["%.1f"%hostTicks[k] for k in xrange(1, len(hostTicks))]), fontsize = fsize2)
                plt.ylabel("Scaled mean\ncoral biomass", horizontalalignment="center", fontsize = fsize2)
            else:
                plt.text(min(N_List) - 0.6e-11, 1, Fig_lab[count-1], fontsize = fsize)
                plt.yticks(list(hostTicks), [" "]+list([" " for k in xrange(1, len(hostTicks))]), fontsize = fsize2)
            if count in (1, 2, 3):
                plt.title(RCP_title[v], fontsize = fsize, fontproperties = font)
                        
        if count in (1, 4, 7):
            sub.tick_params(axis = "y", direction = "in", pad = 2, labelsize = fsize2)
            sub.set_yticks(hostTicks)
            sub.set_yticklabels(["$0$"]+list(["%.1f"%hostTicks[k] for k in xrange(1, len(hostTicks))]))
            part = sub.twinx()
            part.tick_params(axis = "y", direction = "in", pad = 2, labelsize = fsize2)
            part.set_yticks(hostTicks)
            part.set_yticklabels(["" for h in hostTicks])
            part.set_ylim((0, 1))
        else:
            sub.tick_params(axis = "y", direction = "in", pad = 2, labelsize = fsize2)
            sub.set_yticks(hostTicks)
            sub.set_yticklabels(["" for h in hostTicks])
            part = sub.twinx()
            part.tick_params(axis = "y", direction = "in", pad = 2, labelsize = fsize2)
            part.set_yticks(hostTicks)
            part.set_yticklabels(["" for h in hostTicks])
            part.set_ylim((0, 1))
        sub.set_xlim((min(N_List), 10e-11))
        sub.set_ylim((0, 1))
        if count == 1:    
            #sub.legend(loc=(-0.75, 1.25), fontsize = fsize2, ncol = 5)  
            sub.legend(loc=(0.5, 1.25), fontsize = fsize, ncol = 5) 
        count+=1

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 
plt.show()