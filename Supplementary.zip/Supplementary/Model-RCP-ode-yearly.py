# -*- coding: utf-8 -*-
from __future__ import division

from scipy import exp, linspace, array, zeros, e, sqrt, mean,var, ones, cumsum, random, sin, pi, load
from scipy.stats import norm
from numpy import amin, amax, meshgrid, arange, isnan, logical_not, interp, concatenate, arange, isnan
from scipy.integrate import ode
from matplotlib import pyplot as plt
import matplotlib


#### Model with a dynamics on the symbiont biomass, Time in year #####
G_C = 10  # this is G_max in the model
a = 1.0768 # Symbiont specific growth rate - linear growth rate
b = 0.0633 # Exponential Growth constant of the symbiont


alpha = 1e-3

M_C = 10e-3 # coral mortality 

# Regional coral carrying capacity
K_C_GBR = 438718.902336e10 # in cm^2
K_C_SEA = 1191704.68901e10 # in cm^2
K_C_CAR = 190374.697987e10  # in cm^2

K_C_List = [K_C_GBR, K_C_SEA, K_C_CAR]


Ksmax = 3e6 # healthy measure of carying capacity of symbiont per host biomass Gamma

beta = 1e2

gammaH = 1e6 # free param 
fsize = 18

r = 1e3
error = 1e-2 # prevent division by zeros these scales are alright because we are dealing with very high numbers
error2 = 1e-2 # prevent division by zeros
error3 = 1e-2 # prevent division by zeros

def Gradient(coral, u, symbiont, Gx1, beta, alpha, K_symb, K_C_Reg):
    symbiontH = gammaH*coral
    kappa = symbiont/(symbiontH + symbiont + error3) 
    cost_gam = symbiont/(K_symb + error)
    Grad = Gx1*beta*kappa*(1 - coral/K_C_Reg)*exp(-beta*u) - r*alpha*cost_gam*exp(r*u)
    return Grad

# The following function defines the system of ordinary differential equation to be integrated 
AddTime = 2000 # for spine up
def SystemForcing(t, y, T0, rho, skew, N, NormCor, TempNS, K_C_Reg): 
    dSystem = zeros(len(y))
    coral = y[0]
    u = y[1]
    E = 1 - exp(-beta*u)
    #E = max(0, E) # make sure E is not above 1, due to fast decrease of u making u<0
    symbiont = y[2]
    # Introducing temperature dependence
    #print t
    if t<=NumTime+AddTime:
        Temperature1 = TempNS[t] # this should rather be some function of t and not index but it works here because timestep = 1
    else:
        Temperature1 = TempNS[NumTime+AddTime] # there are index out of range sometimes, maybe because of the integrator, so I just make sure not to get those errors
    Tcenter = (Temperature1-T0)/rho
    Gx1Forcing = G_C*norm.pdf(Tcenter)*norm.cdf(Tcenter*skew)/max(NormCor) # divide by max(NormCor) to make sure that the maximum is G_C at T0
    # Computing the derivative
    K_symb = Ksmax*coral 
    symbiontH = gammaH*coral
    kappa = symbiont/(symbiontH + symbiont + error3)
    cost_gam = symbiont/(K_symb + error)
    Benefit = Gx1Forcing*kappa*E*(1-coral/K_C_Reg)
    Cost =alpha*exp(r*u)*(cost_gam) + M_C
    Fitness = (Benefit - Cost)
    dSystem[0] = Fitness*coral
    dSystem[1] = N*Gradient(coral, u, symbiont, Gx1Forcing, beta, alpha, K_symb, K_C_Reg)
    G_S =  a*exp(b*Temperature1) # symbiont temperature associated growth
    dSystem[2] =G_S*(1-symbiont/(K_symb + error2))*symbiont
    #print K_symb, coral, symbiont, dSystem
    return dSystem

# Parameter resp. for the different region GBR, SEA , CAR
T0_list = array([26.78, 28.13, 27.10]) 
skew_list = array([0.0002, 3.82, 1.06])
rho_list = array([1.0, 0.81, 0.89])

color_list = array([(0.647*col, 0.333*col, 0.075*col) for col in xrange(2,5+2)])/5

scale = (12**2)*1e-11 # same parameters as in monthly time serie simulation but 12**2 convert unit from per month to per year

rawNum_GBR_orig = arange(0.01, 0.1, 0.00005)
rawNum_SEA_orig = arange(0.01, 0.1, 0.00005)
rawNum_CAR_orig = arange(0.01, 0.1, 0.00005) 

# For dynamics simulation Results/
rawNum_GBR = rawNum_GBR_orig
rawNum_SEA = rawNum_SEA_orig
rawNum_CAR = rawNum_CAR_orig

TempList = linspace(0, 75, 1500)
RCP_list = ["RCP26", "RCP45", "RCP85"]

Locations = array(["GBR", "SEA", "CAR"])

for rcp_index in xrange(len(RCP_list)):
    RCP = RCP_list[rcp_index]
    print RCP
    for z in xrange(len(Locations)):
        plt.figure()
        sub1 = plt.subplot(3, 1, 1)
        sub2 = plt.subplot(3, 1, 2)
        sub3 = plt.subplot(3, 1, 3)
        #variable time
        file0 = open("Years-"+Locations[z]+"-"+RCP+"-MPI"+".dat", "r")
        time = load(file0)   
        file0.close()
        #Scenarios
        file1 = open("SST-"+Locations[z]+"-"+RCP+"-MPI"+".dat", "r")
        TempNSdata = load(file1)
        file1.close()
        
        TimeYear = arange(0, len(time), 1.0) # this is the same as time but in terms of time[0] is initial time of dynamics
        NumTime = len(TimeYear) - 1
        
        HOST = []
        TRAIT = []
        SYMB = []
        T0 = T0_list[z]
        skew = skew_list[z]
        rho = rho_list[z]
        K_C_Reg = K_C_List[z]
       
                       
        TempNS = concatenate((mean(TempNSdata[time<=2000])*ones(AddTime+1), TempNSdata)) # use mean(TempNSdata[time<=2000]) = mean WOD13 before year 2000 as initial temperature profile for spine up
        TempCORListCenter = (TempList - T0)/rho
        NormCor = norm.pdf(TempCORListCenter)*norm.cdf(TempCORListCenter*skew)
        
        # uncomment 3 lines bellow to create the result data files 
        fileCoral = open("Results/"+RCP+"/CORAL-"+RCP+"-"+Locations[z]+".dat", "wr")
        fileTrait = open("Results/"+RCP+"/TRAIT-"+RCP+"-"+Locations[z]+".dat", "wr")
        fileSymb = open("Results/"+RCP+"/SYMB-"+RCP+"-"+Locations[z]+".dat", "wr")
        if z == 0:
            N_List = (scale)*rawNum_GBR
            Initial = array([0.75*K_C_GBR, 0.0000005, 0.001]) 
        elif z == 1:
            N_List = (scale)*rawNum_SEA
            Initial = array([0.75*K_C_SEA, 0.0000005, 0.001]) 
        else:
            N_List = (scale)*rawNum_CAR
            Initial = array([0.75*K_C_CAR, 0.0000005, 0.001]) 
        for i in xrange(len(N_List)):
            N = N_List[i]
            ode15s = ode(SystemForcing)
            ode15s.set_f_params(T0, rho, skew, N, NormCor, TempNS, K_C_Reg)
            # Choosing an integrator choosing a solver that can deal stiff problems since the yearly yearly temperature forcing is not entirely smooth
            ode15s.set_integrator('vode', method='bdf', order=15, nsteps=3000)
            ode15s.set_initial_value(Initial, 0)
            Dynamics = zeros((len(time)+AddTime+1 , 3))
            Dynamics[0, 0] = ode15s.y[0]
            Dynamics[0, 1] = ode15s.y[1]
            Dynamics[0, 2] = ode15s.y[2]
            k=1
            while ode15s.successful() and ode15s.t <= len(time)-2+AddTime+1:
                ode15s.integrate(ode15s.t+1)
                Dynamics[k, 0] = ode15s.y[0]
                Dynamics[k, 1] = ode15s.y[1]
                Dynamics[k, 2] = ode15s.y[2]
                k+=1
                print RCP, Locations[z], i, k
            HOST.append(Dynamics[:, 0])
            TRAIT.append(Dynamics[:, 1])
            SYMB.append(Dynamics[:, 2])
            sub1.plot(Dynamics[AddTime:, 0])
            sub2.plot(Dynamics[AddTime:, 1])
            sub3.plot(Dynamics[AddTime:, 2])
        plt.savefig(Locations[z]+"-"+RCP+".pdf")
        
        # uncomment 9 lines bellow to save the result data
        array(HOST).dump(fileCoral)
        array(TRAIT).dump(fileTrait)
        array(SYMB).dump(fileSymb)
        fileCoral.flush()
        fileTrait.flush()
        fileSymb.flush()
        fileCoral.close()
        fileTrait.close()
        fileSymb.close()
    
plt.show()