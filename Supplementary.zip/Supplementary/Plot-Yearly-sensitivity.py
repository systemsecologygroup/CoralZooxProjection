# -*- coding: utf-8 -*-
from __future__ import division

from scipy import exp, linspace, array, zeros, e, sqrt, mean,var, ones, cumsum, random, sin, pi, load
from scipy.stats import norm
from numpy import amin, amax, meshgrid, arange, isnan, logical_not, interp, concatenate, floor
from scipy.integrate import odeint
from matplotlib import pyplot as plt
import matplotlib
from matplotlib.font_manager import FontProperties
plt.switch_backend('agg')

#### Plotting data collected from ode solver #####

font = {'family' : 'normal',
        'weight' : 'bold'}
#matplotlib.rc('font',**{'family':'Times', 'sans-serif':['Times']})
#matplotlib.rc('text', usetex = True)
#matplotlib.rc('font', **font)


plt.rcParams["font.family"] = "arial"   

font0 = FontProperties()
font = font0.copy()
weight = "bold"
font.set_weight(weight)   
# Needed Parameters
Ksmax = 3e6 # healthy measure of carying capacity of symbiont per host biomass Gamma

# Temperature limited growth
T0_list = array([26.78, 28.13, 27.10]) 
skew_list = array([0.0002, 3.82, 1.06])
rho_list = array([1.0, 0.81, 0.89])

# For model with bleaching
scale = (12**2)*1e-11
rawNum_GBR = arange(0.01, 0.1, 0.00005)
rawNum_SEA = arange(0.01, 0.1, 0.00005)
rawNum_CAR = arange(0.01, 0.1, 0.00005) 

fsize = 12 #18 #22
fsize2 = 11 #18

# Open Files

Locations = ["GBR", "SEA", "CAR"]
RCP = ["RCP26", "RCP45", "RCP85"] # for filename
#RCP_title =  ["Low (RCP2.6)", "Moderate (RCP4.5)", "High (RCP8.5)"]
RCP_title =  ["RCP 2.6", "RCP 4.5", "RCP 8.5"]
Fig_lab = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l"]
#Fig_lab = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L"]

# Colorbar setting
import matplotlib.colors as mcolors
import matplotlib as mpl
 
fig =plt.figure(figsize=(14, 20))
ax = plt.subplot(1, 1, 1)

AddTime = 2000 # spine up of 2000 years

Color_list = [(0.306, 0.431+0.1, 0.545+0.3), (0.839+0.025, 0.60+0.05, 0.20), (0.839+0.16, 0.363, 0.35)]
Locations_title = ["Great Barrier Reef", "South East Asia", "Caribbean"]

# Plot parameter sensitivity Supplementary (Bar plot)

scale = (12**2)*1e-11

rawNum_GBR_orig = arange(0.01, 0.1, 0.00005)
rawNum_SEA_orig = arange(0.01, 0.1, 0.00005)
rawNum_CAR_orig = arange(0.01, 0.1, 0.00005) 

#  Speed of acclimation specific for each region for main results
GBR_N_index_orig = 908 # index in rawNum_GBR  0.0554
SEA_N_index_orig = 330 # index in rawNum_SEA  0.0265
CAR_N_index_orig= 275 # index in rawNum_CAR  0.02375
reg_N_index_orig = [GBR_N_index_orig, SEA_N_index_orig, CAR_N_index_orig]

# Runs in Sensitivity_N/Sensitivity (generated with Sensitivity-RCP-yearly.py) and Sensitivity-N/Senstivity-Fix-other-Params an +/-25 % in N (generated with Model-RCP-ode-yearly.py)
rawNum_GBR = concatenate((array([0.75*rawNum_GBR_orig[GBR_N_index_orig]]), array([rawNum_GBR_orig[GBR_N_index_orig]]), array([1.25*rawNum_GBR_orig[GBR_N_index_orig]])))
rawNum_SEA = concatenate((array([0.75*rawNum_SEA_orig[SEA_N_index_orig]]), array([rawNum_SEA_orig[SEA_N_index_orig]]), array([1.25*rawNum_SEA_orig[SEA_N_index_orig]])))
rawNum_CAR = concatenate((array([0.75*rawNum_CAR_orig[CAR_N_index_orig]]), array([rawNum_CAR_orig[CAR_N_index_orig]]), array([1.25*rawNum_CAR_orig[CAR_N_index_orig]]))) 

# Indexes corresponding to specific speed of adaptation including the -25% and +25% 
GBR_N_index_minus = 0 #len(arange(min(rawNum_GBR_orig), rawNum_GBR_orig[GBR_N_index_orig], 0.0005))
GBR_N_index = 1
GBR_N_index_plus = 2

SEA_N_index_minus = 0
SEA_N_index = 1
SEA_N_index_plus = 2

CAR_N_index_minus = 0
CAR_N_index = 1
CAR_N_index_plus = 2

reg_N_index_minus = [GBR_N_index_minus, SEA_N_index_minus, CAR_N_index_minus]
reg_N_index = [GBR_N_index, SEA_N_index, CAR_N_index]
reg_N_index_plus = [GBR_N_index_plus, SEA_N_index_plus, CAR_N_index_plus]

# Regional coral carrying capacity
K_C_GBR = 438718.902336e10 # in cm^2
K_C_SEA = 1191704.68901e10 # in cm^2
K_C_CAR = 190374.697987e10  # in cm^2
K_C_List = [K_C_GBR, K_C_SEA, K_C_CAR]

file_list = ["Sensitivity-params/Yearly/"] #### Specific folder for the sensitivity simulations "Sensitivity-RCP-yearly-1.py"

# + or - 25% change
ParamsPlus= ["Gmax-Plus", "a-Plus", "b-Plus", "KC-Plus", "Ksmax-Plus", "MC-Plus", "alpha-Plus", "r-Plus", "beta-Plus", "GammaH-Plus", "N-Plus"]
ParamsMinus= ["Gmax-Minus", "a-Minus", "b-Minus", "KC-Minus", "Ksmax-Minus", "MC-Minus", "alpha-Minus", "r-Minus", "beta-Minus", "GammaH-Minus", "N-Minus"]
Params = ["$G_{max}$", "$a$", "$b$", "$K_C$", "$K_{smax}$", "$M_C$", r"$\alpha$", "$r$", r"$\beta$", r"$\Gamma_h$", "$N$"]
NumP = linspace(1.5, 30, len(Params) + 1) 
ChosenStart = -100 # comparing betweeen year 2000 and 2100
width = 0.6
count = 1

for z in xrange(len(Locations)):
    for v in xrange(len(RCP)):
        sub = plt.subplot(3, 3, count)
        rcp = RCP[v]
        #variable time
        file0 = open("Yearly-SST-scenarios/Years-"+Locations[z]+"-"+rcp+"-MPI"+".dat", "r")
        time = load(file0, allow_pickle = True)   
        file0.close()
        #Scenarios
        file1 = open("Yearly-SST-scenarios/SST-"+Locations[z]+"-"+rcp+"-MPI"+".dat", "r")
        TempNSdata = load(file1, allow_pickle = True)
        file1.close()
        
        for file_index in xrange(len(file_list)):
            filename = file_list[file_index]
            
            # 1 simulation, standard run without change in any parameters 
            file2 = open(filename+"Standard/"+"/CORAL-"+rcp+"-"+Locations[z]+".dat", "r")
            HOSTSet1 = load(file2, allow_pickle = True)
            file2.close()
         
            Host = HOSTSet1[0]
        
        
            MeanlossCoralBiomass = []
            
            ResCoralPlus = zeros(len(ParamsPlus))
            ResSymbPlus = zeros(len(ParamsPlus))
            ResTraitPlus = zeros(len(ParamsPlus))
        
            ResCoralMinus = zeros(len(ParamsPlus))
            ResSymbMinus = zeros(len(ParamsPlus))
            ResTraitMinus = zeros(len(ParamsPlus))
            if file_index == 0 and z == 0:
                N_index = reg_N_index[z]
                print Locations[z], filename, rawNum_GBR[N_index], rawNum_GBR_orig[reg_N_index_orig[z]] 
                ResCoralPlusDiff = zeros(len(ParamsPlus)+1)
                ResCoralMinusDiff = zeros(len(ParamsPlus)+1)  
                for ind in xrange(len(Params)):
                    changePlus = 1.25
                    changeMinus = 0.75
                    K_C_Reg = K_C_List[z]
                    if Params[ind] == "$K_C$":
                        K_C_plus =  changePlus*K_C_Reg
                        K_C_minus = changeMinus*K_C_Reg
                    else:
                        K_C_plus =  K_C_Reg
                        K_C_minus = K_C_Reg
                    
                    # always contain 1 simulation with the parameter setting
                    fileCoral = open(filename+"Sensitivity/CORAL-"+rcp+"-"+Locations[z]+"-"+ParamsPlus[ind]+".dat", "r")
                    Coral_plus = load(fileCoral, allow_pickle = True)
                    fileCoral.close()

                    
                    fileCoral = open(filename+"Sensitivity/CORAL-"+rcp+"-"+Locations[z]+"-"+ParamsMinus[ind]+".dat", "r")
                    Coral_minus = load(fileCoral, allow_pickle = True)
                    fileCoral.close()
          
                      
                    ResCoralPlusDiff[ind] = 100*(mean(Coral_plus[0, ChosenStart:]) - mean(Host[ChosenStart:]))/mean(Host[ChosenStart:])
                    ResCoralMinusDiff[ind] = 100*(mean(Coral_minus[0, ChosenStart:]) - mean(Host[ChosenStart:]))/mean(Host[ChosenStart:])
                   
                
                sub.plot(NumP, zeros(len(NumP)), linewidth = 1, color = "black")                  
                sub.bar(NumP, ResCoralPlusDiff, width, color = (0.463, 0.647, 0.647), label = "$+25\%$")  
                sub.bar(NumP+width, ResCoralMinusDiff, width, color = (0.008, 0.22, 0.278), label = "$-25\%$") 
            elif file_index == 0 and z == 1:
                N_index = reg_N_index[z]
                print Locations[z], filename, rawNum_SEA[N_index], rawNum_SEA_orig[reg_N_index_orig[z]] 
                ResCoralPlusDiff = zeros(len(ParamsPlus)+1)
                ResCoralMinusDiff = zeros(len(ParamsPlus)+1)
                for ind in xrange(len(Params)):
                    changePlus = 1.25 
                    changeMinus = 0.75
                    K_C_Reg = K_C_List[z]
                    if Params[ind] == "$K_C$":
                        K_C_plus =  changePlus*K_C_Reg
                        K_C_minus = changeMinus*K_C_Reg
                    else:
                        K_C_plus =  K_C_Reg
                        K_C_minus = K_C_Reg
                    
                    # always contain 1 simulation with the parameter setting
                    fileCoral = open(filename+"Sensitivity/CORAL-"+rcp+"-"+Locations[z]+"-"+ParamsPlus[ind]+".dat", "r")
                    Coral_plus = load(fileCoral, allow_pickle = True)
                    fileCoral.close()

                    
                    fileCoral = open(filename+"Sensitivity/CORAL-"+rcp+"-"+Locations[z]+"-"+ParamsMinus[ind]+".dat", "r")
                    Coral_minus = load(fileCoral, allow_pickle = True)
                    fileCoral.close()
          
                      
                    ResCoralPlusDiff[ind] = 100*(mean(Coral_plus[0, ChosenStart:]) - mean(Host[ChosenStart:]))/mean(Host[ChosenStart:])
                    ResCoralMinusDiff[ind] = 100*(mean(Coral_minus[0, ChosenStart:]) - mean(Host[ChosenStart:]))/mean(Host[ChosenStart:])

                sub.plot(NumP, zeros(len(NumP)), linewidth = 1, color = "black")                  
                sub.bar(NumP, ResCoralPlusDiff, width, color = (0.463, 0.647, 0.647), label = "$+25\%$")  
                sub.bar(NumP+width, ResCoralMinusDiff, width, color = (0.008, 0.22, 0.278), label = "$-25\%$")   
            elif file_index == 0 and z == 2:
                N_index = reg_N_index[z]
                print Locations[z], filename, rawNum_CAR[N_index], rawNum_CAR_orig[reg_N_index_orig[z]]
                ResCoralPlusDiff = zeros(len(ParamsPlus)+1)
                ResCoralMinusDiff = zeros(len(ParamsPlus)+1)
                for ind in xrange(len(Params)):
                    changePlus = 1.25
                    changeMinus = 0.75
                    K_C_Reg = K_C_List[z]
                    if Params[ind] == "$K_C$":
                        K_C_plus =  changePlus*K_C_Reg
                        K_C_minus = changeMinus*K_C_Reg
                    else:
                        K_C_plus =  K_C_Reg
                        K_C_minus = K_C_Reg
                    
                    # always contain 1 simulation with the parameter setting
                    fileCoral = open(filename+"Sensitivity/CORAL-"+rcp+"-"+Locations[z]+"-"+ParamsPlus[ind]+".dat", "r")
                    Coral_plus = load(fileCoral, allow_pickle = True)
                    fileCoral.close()

                    
                    fileCoral = open(filename+"Sensitivity/CORAL-"+rcp+"-"+Locations[z]+"-"+ParamsMinus[ind]+".dat", "r")
                    Coral_minus = load(fileCoral, allow_pickle = True)
                    fileCoral.close()
          
                      
                    ResCoralPlusDiff[ind] = 100*(mean(Coral_plus[0, ChosenStart:]) - mean(Host[ChosenStart:]))/mean(Host[ChosenStart:])
                    ResCoralMinusDiff[ind] = 100*(mean(Coral_minus[0, ChosenStart:]) - mean(Host[ChosenStart:]))/mean(Host[ChosenStart:])
                
                sub.plot(NumP, zeros(len(NumP)), linewidth = 1, color = "black")                  
                sub.bar(NumP, ResCoralPlusDiff, width, color = (0.463, 0.647, 0.647), label = "$+25\%$")  
                sub.bar(NumP+width, ResCoralMinusDiff, width, color = (0.008, 0.22, 0.278), label = "$-25\%$")  
        if count in (7, 8, 9):
            plt.xticks(NumP+(0.5)*width, Params+["$N$"], rotation = 65, fontsize = fsize2+2)
        else:
            plt.xticks(NumP+(0.5)*width, [" " for i in xrange(len(Params))], fontsize = fsize2, fontproperties = font)  
        if count in (1, 2, 3):
            plt.title(RCP_title[v], fontproperties = font, fontsize = fsize)
        if count in (1, 4, 7):
            sub.tick_params(axis = "y", direction = "in", pad = 2, labelsize = fsize2)
            sub.set_yticks((-125, -100, -75, -50, -25, 0, 25, 50, 75, 100, 125))
            #sub.set_yticklabels(("-125", "-100", "-75", "-25", "0", "25", "50", "75", "100", "125"))
            part = sub.twinx()
            part.tick_params(axis = "y", direction = "in", pad = 2, labelsize = fsize2)
            part.set_yticks((-125, -100, -75, -50, -25, 0, 25, 50, 75, 100, 125))
            part.set_yticklabels(("", "", "", "", "", "", "", "", "", "", ""))
            part.set_ylim((-125, 75))
            if z == 0:
                sub.text(-12, 105-50, Locations_title[z], fontproperties = font, fontsize = 13, rotation = "vertical") # fontsize = 16
            elif z == 1:
                sub.text(-12, 85-50, Locations_title[z], fontproperties = font, fontsize = 13, rotation = "vertical") # fontsize = 16
            else:
                sub.text(-12, 65-50, Locations_title[z], fontproperties = font, fontsize = 13, rotation = "vertical") # fontsize = 16
            sub.text(-6, 125-50, Fig_lab[count-1], fontproperties = font, fontsize = fsize)
            sub.set_ylabel("$\%$ change in mean \n coral biomass", fontsize = fsize2)
        else:
            sub.tick_params(axis = "y", direction = "in", pad = 2, labelsize = fsize2)
            sub.set_yticks((-125, -100, -75, -50, -25, 0, 25, 50, 75, 100, 125))
            sub.set_yticklabels(("", "", "", "", "", "", "", "", "", "", ""))
            part = sub.twinx()
            part.tick_params(axis = "y", direction = "in", pad = 2, labelsize = fsize2)
            part.set_yticks((-125, -100, -75, -50, -25, 0, 25, 50, 75, 100, 125))
            part.set_yticklabels(("", "", "", "", "", "", "", "", "", "", ""))
            part.set_ylim((-125, 75))
            sub.text(-2, 125-50, Fig_lab[count-1], fontproperties = font, fontsize = 13)

        sub.set_ylim((-125, 75))   
        
        if count == 1:
            sub.legend(loc="best", fontsize = fsize2, ncol = 2, frameon = False) 
       
        count+=1

plt.subplots_adjust(top=0.965,
bottom=0.095,
left=0.080,
#right=0.81,
right = 0.75,
hspace=0.175,
wspace=0.175)

plt.savefig("SensParams-yearly.pdf", bbox_inches = 'tight')    

# Sensitivity with respect to speed of acclimation
"""                                                                                                                                                                    
count = 1
ChosenStart = -100 # year before 2100 to start comparison
# Regional coral carrying capacity
K_C_GBR = 438718.902336e10 # in cm^2
K_C_SEA = 1191704.68901e10 # in cm^2
K_C_CAR = 190374.697987e10  # in cm^2
K_C_List = [K_C_GBR, K_C_SEA, K_C_CAR]
file_list = ["Results-final/Yearly/"] #### Specific folder for the sensitivity simulations "Sensitivity-RCP-yearly-2.py"

# + or - 25% change
ParamsPlus= ["Gmax-Plus", "a-Plus", "b-Plus", "KC-Plus", "Ksmax-Plus", "MC-Plus", "alpha-Plus", "r-Plus", "beta-Plus", "GammaH-Plus"]
ParamsMinus= ["Gmax-Minus", "a-Minus", "b-Minus", "KC-Minus", "Ksmax-Minus", "MC-Minus", "alpha-Minus", "r-Minus", "beta-Minus", "GammaH-Minus"]
Params = ["$G_{max}$", "$a$", "$b$", "$K_C$", "$K_{smax}$", "$M_C$", r"$\alpha$", "$r$", r"$\beta$", r"$\Gamma_h$"]
NumP = linspace(1.5, 30, len(Params) + 1) 
col = [(1, 0.667, 0.667), (0.831, 0.416, 0.416), (0.502, 0.1, 0.1)]
ChosenStart = -100*12 # comparing betweeen year 2000 and 2100

cmx = mpl.cm
cmapC = mpl.cm.Set1
#cNorm = mpl.colors.Normalize(vmin=N_List.min(), vmax=N_List.max())
cNorm = mpl.colors.Normalize(vmin=0, vmax=len(Params))
scalarMap = cmx.ScalarMappable(norm=cNorm, cmap=cmapC)
# These are not the index of estimated N reported in manuscript, it was from earlier code versions, the choice does not matter
GBR_N_index_sim = 100 # index in rawNum_GBR  0.0145
SEA_N_index_sim = 275 # index in rawNum_SEA  0.02375
CAR_N_index_sim = 250 # index in rawNum_CAR  0.0225
"""
# Only for sensitivity simulations to reduce the number of simulations (USED for supplementary figure in manuscript)
#rawNum_GBR = concatenate((arange(min(rawNum_GBR_orig), rawNum_GBR_orig[GBR_N_index], 0.0005), array([0.75*rawNum_GBR_orig[GBR_N_index]]), array([rawNum_GBR_orig[GBR_N_index]]), array([1.25*rawNum_GBR_orig[GBR_N_index]]), arange(rawNum_GBR_orig[GBR_N_index]+0.0005, max(rawNum_GBR_orig), 0.0005)))
#rawNum_SEA = concatenate((arange(min(rawNum_SEA_orig), rawNum_SEA_orig[SEA_N_index], 0.0005), array([0.75*rawNum_SEA_orig[SEA_N_index]]), array([rawNum_SEA_orig[SEA_N_index]]), array([1.25*rawNum_SEA_orig[SEA_N_index]]), arange(rawNum_SEA_orig[SEA_N_index]+0.0005, max(rawNum_SEA_orig), 0.0005)))
#rawNum_CAR = concatenate((arange(min(rawNum_CAR_orig), rawNum_CAR_orig[CAR_N_index], 0.0005), array([0.75*rawNum_CAR_orig[CAR_N_index]]), array([rawNum_CAR_orig[CAR_N_index]]), array([1.25*rawNum_CAR_orig[CAR_N_index]]), arange(rawNum_CAR_orig[CAR_N_index]+0.0005, max(rawNum_CAR_orig), 0.0005))) 
"""
# Only for sensitivity simulations to reduce the number of simulations (Just for a DEMO here)
rawNum_GBR = concatenate((arange(min(rawNum_GBR_orig), rawNum_GBR_orig[GBR_N_index], 0.05), array([rawNum_GBR_orig[GBR_N_index]]), arange(rawNum_GBR_orig[GBR_N_index]+0.05, max(rawNum_GBR_orig), 0.05)))
rawNum_SEA = concatenate((arange(min(rawNum_SEA_orig), rawNum_SEA_orig[SEA_N_index], 0.05), array([rawNum_SEA_orig[SEA_N_index]]), arange(rawNum_SEA_orig[SEA_N_index]+0.05, max(rawNum_SEA_orig), 0.05)))
rawNum_CAR = concatenate((arange(min(rawNum_CAR_orig), rawNum_CAR_orig[CAR_N_index], 0.05), array([rawNum_CAR_orig[CAR_N_index]]), arange(rawNum_CAR_orig[CAR_N_index]+0.05, max(rawNum_CAR_orig), 0.05))) 

# Parameters to study sensitivity to
ParamsPlus= ["Gmax-Plus", "a-Plus", "b-Plus", "KC-Plus", "Ksmax-Plus", "MC-Plus", "alpha-Plus", "r-Plus", "beta-Plus", "GammaH-Plus"]
ParamsMinus= ["Gmax-Minus", "a-Minus", "b-Minus", "KC-Minus", "Ksmax-Minus", "MC-Minus", "alpha-Minus", "r-Minus", "beta-Minus", "GammaH-Minus"]
Params = ParamsPlus + ParamsMinus

#  Speed of acclimation specific for each region for main results, to indicate on the plot
GBR_N_index = 908 # index in rawNum_GBR  0.0554
SEA_N_index = 330 # index in rawNum_SEA  0.0265
CAR_N_index = 275 # index in rawNum_CAR  0.02375
reg_N_index = [GBR_N_index, SEA_N_index, CAR_N_index]

filename = "Sensitivity-N/Yearly/"
PlusOrMinus = "Plus"

from scipy import interpolate   
for z in xrange(len(Locations)):
    for v in xrange(len(RCP)):            
        rcp = RCP[v] 
        #print Locations[z], rcp, count           
        sub = plt.subplot(3, 3, count)
        for ind in xrange(len(Params)):
            CORval = array([])
            N_full = array([])
            for file_index in xrange(len(file_list)):
                
                if PlusOrMinus == "Plus":
                    change = 1.25 # 0.75 for ParamsMinus and 1.25 for ParamsPlus
                    fileLab = ParamsPlus[ind]
                else:
                    change = 0.75
                    fileLab = ParamsMinus[ind]
                    
                file2 = open(filename+rcp+"/CORAL-"+rcp+"-"+Locations[z]+"-"+fileLab+".dat", "r")
                HOSTSet1 = load(file2, allow_pickle = True)
                file2.close()
            
                file3 = open(filename+rcp+"/TRAIT-"+rcp+"-"+Locations[z]+"-"+fileLab+".dat", "r")
                TRAITSet1 = load(file3, allow_pickle = True)
                file3.close()
            
                file4 =  open(filename+rcp+"/SYMB-"+rcp+"-"+Locations[z]+"-"+fileLab+".dat", "r")
                SYMBSet1 = load(file4, allow_pickle = True)
                file4.close()
                

                HOST = HOSTSet1
                SYMB = SYMBSet1
                TRAIT = TRAITSet1
                K_C = K_C_List[z]
                if file_index == 0 and z == 0:
                    rawNum_orig = rawNum_GBR_orig
                    rawNum = rawNum_GBR
                    N_List_orig = (scale)*rawNum_orig
                    N_List = (scale)*rawNum
                    sub.plot(N_List_orig[reg_N_index[z]]*ones(2), linspace(0, 1, 2), color = Color_list[0], linewidth = 4)
                elif file_index == 0 and z == 1:
                    rawNum_orig = rawNum_SEA_orig
                    rawNum = rawNum_SEA
                    N_List_orig = (scale)*rawNum_orig
                    N_List = (scale)*rawNum
                    sub.plot(N_List_orig[reg_N_index[z]]*ones(2), linspace(0, 1, 2), color = Color_list[0], linewidth = 4)
                elif file_index == 0 and z == 2:
                    rawNum_orig = rawNum_CAR_orig
                    rawNum = rawNum_CAR
                    N_List_orig = (scale)*rawNum_orig
                    N_List = (scale)*rawNum
                    sub.plot(N_List_orig[reg_N_index[z]]*ones(2), linspace(0, 1, 2), color = Color_list[0], linewidth = 4)
                print rawNum_orig[reg_N_index[z]], N_List_orig[reg_N_index[z]]
                ResCoral = zeros((len(Params), len(rawNum)))
                ResSymb = zeros((len(Params), len(rawNum)))
                ResTrait = zeros((len(Params), len(rawNum)))
            
                LocResCoral = zeros(len(rawNum))
                LocResSymb = zeros(len(rawNum))
                LocResTrait = zeros(len(rawNum))
                for i in xrange(len(rawNum)): 
                    if Params[ind] == "$K_C$":
                        LocResCoral[i] = mean(HOST[i][ChosenStart:])/(change*K_C)
                        LocResSymb[i] = mean(TRAIT[i][ChosenStart:])
                        LocResTrait[i] = mean(SYMB[i][ChosenStart:])  
                    else:
                        LocResCoral[i] = mean(HOST[i][ChosenStart:])/K_C
                        LocResSymb[i] = mean(TRAIT[i][ChosenStart:])
                        LocResTrait[i] = mean(SYMB[i][ChosenStart:])                    
                ResCoral[ind, :] = LocResCoral
                ResSymb[ind, :] = LocResSymb
                ResTrait[ind, :] = LocResTrait
                
                CORval = concatenate((CORval, ResCoral[ind, :]*((ind+3+1)/(len(Params)+3))))
                N_full = concatenate((N_full, N_List))
            if Params[ind] != r"$\Gamma_h$":
                colorval0 = scalarMap.to_rgba(ind+1)
            else:
                colorval0 = "black" 
            
            #  interpolate because unsorted values, not necessarily unique as well
            f = interpolate.interp1d(array(N_full), array(CORval), kind="cubic")
            N_new = linspace(min(N_full), max(N_full), 200)
            CORval_new = f(N_new)
            if count == 1:
                sub.plot(N_new, CORval_new, linewidth = 2, color = colorval0, label=Params[ind])#+ " (scaling = %.2f/$K_C$)"%((ind+3+1)/(len(Params)+3), ))
            else:
                sub.plot(N_new, CORval_new, linewidth = 2, color = colorval0)         
            if count not in (7, 8, 9):
                plt.xticks(array([1.44, 2, 3, 4, 5, 6, 7, 8, 9, 10])*1e-11, [" " for i in [1.44, 2, 3, 4, 5, 6, 7, 8, 9, 10]])
            else: 
                plt.xticks(array([1.44, 2, 3, 4, 5, 6, 7, 8, 9, 10])*1e-11, [""]+["%d"%N for N in [2, 3, 4, 5, 6, 7, 8, 9, 10]], fontsize=fsize2)
                plt.xlabel(r'Speed of acclimation $N$ $\times$ $10^{11}$', fontsize = fsize2)
            if count in (1, 4, 7):
                if z == 0:
                    plt.text(min(N_List) - 3e-11, 0.9, Locations_title[z], fontsize = fsize, fontproperties = font,  rotation = "vertical")
                if z == 1:
                    plt.text(min(N_List) - 3e-11, 0.85, Locations_title[z], fontsize = fsize, fontproperties = font,  rotation = "vertical")
                if z == 2:
                    plt.text(min(N_List) - 3e-11, 0.72, Locations_title[z], fontsize = fsize, fontproperties = font,  rotation = "vertical")    
                plt.text(min(N_List) - 1.2e-11, 1, Fig_lab[count-1], fontsize = fsize)
                hostTicks = array([0., 0.2, 0.4, 0.6, 0.8, 1.0])
                plt.yticks(list(hostTicks), ["$0$"]+list(["%.1f"%hostTicks[k] for k in xrange(1, len(hostTicks))]), fontsize = fsize2)
                plt.ylabel("Scaled mean\ncoral biomass", horizontalalignment="center", fontsize = fsize2)
            else:
                plt.text(min(N_List) - 0.6e-11, 1, Fig_lab[count-1], fontsize = fsize)
                plt.yticks(list(hostTicks), [" "]+list([" " for k in xrange(1, len(hostTicks))]), fontsize = fsize2)
            if count in (1, 2, 3):
                plt.title(RCP_title[v], fontsize = fsize, fontproperties = font)
                        
        if count in (1, 4, 7):
            sub.tick_params(axis = "y", direction = "in", pad = 2, labelsize = fsize2)
            sub.set_yticks(hostTicks)
            sub.set_yticklabels(["$0$"]+list(["%.1f"%hostTicks[k] for k in xrange(1, len(hostTicks))]))
            part = sub.twinx()
            part.tick_params(axis = "y", direction = "in", pad = 2, labelsize = fsize2)
            part.set_yticks(hostTicks)
            part.set_yticklabels(["" for h in hostTicks])
            part.set_ylim((0, 1))
        else:
            sub.tick_params(axis = "y", direction = "in", pad = 2, labelsize = fsize2)
            sub.set_yticks(hostTicks)
            sub.set_yticklabels(["" for h in hostTicks])
            part = sub.twinx()
            part.tick_params(axis = "y", direction = "in", pad = 2, labelsize = fsize2)
            part.set_yticks(hostTicks)
            part.set_yticklabels(["" for h in hostTicks])
            part.set_ylim((0, 1))
        sub.set_xlim((min(N_List), 10e-11))
        sub.set_ylim((0, 1))
        if count == 1:    
            #sub.legend(loc=(-0.75, 1.25), fontsize = fsize2, ncol = 5)  
            sub.legend(loc=(0.5, 1.25), fontsize = fsize, ncol = 5) 
        count+=1

plt.subplots_adjust(top=0.965,
bottom=0.095,
left=0.080,
#right=0.81,
right = 0.75,
hspace=0.175,
wspace=0.175)

if fileLab == "Plus":
    plt.savefig("SensN-yearly-Plus.pdf", bbox_inches = 'tight')
else:
    plt.savefig("SensN-yearly-Minus.pdf", bbox_inches = 'tight') 
"""                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  
plt.show()